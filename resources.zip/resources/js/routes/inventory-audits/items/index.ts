import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\InventoryAuditController::count
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
export const count = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: count.url(args, options),
    method: 'post',
})

count.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/items/{item}/count',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::count
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
count.url = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                    item: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                                item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return count.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::count
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
count.post = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: count.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::count
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
    const countForm = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: count.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::count
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
        countForm.post = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: count.url(args, options),
            method: 'post',
        })
    
    count.form = countForm
/**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
export const resolve = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolve.url(args, options),
    method: 'post',
})

resolve.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/items/{item}/resolve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
resolve.url = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                    item: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                                item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return resolve.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
resolve.post = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
    const resolveForm = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resolve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
        resolveForm.post = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resolve.url(args, options),
            method: 'post',
        })
    
    resolve.form = resolveForm
const items = {
    count: Object.assign(count, count),
resolve: Object.assign(resolve, resolve),
}

export default items