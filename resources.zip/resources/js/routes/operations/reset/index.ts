import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\OperationalDataResetController::index
 * @see app/Http/Controllers/OperationalDataResetController.php:19
 * @route '/operations/reset'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/operations/reset',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\OperationalDataResetController::index
 * @see app/Http/Controllers/OperationalDataResetController.php:19
 * @route '/operations/reset'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OperationalDataResetController::index
 * @see app/Http/Controllers/OperationalDataResetController.php:19
 * @route '/operations/reset'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\OperationalDataResetController::index
 * @see app/Http/Controllers/OperationalDataResetController.php:19
 * @route '/operations/reset'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\OperationalDataResetController::index
 * @see app/Http/Controllers/OperationalDataResetController.php:19
 * @route '/operations/reset'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\OperationalDataResetController::index
 * @see app/Http/Controllers/OperationalDataResetController.php:19
 * @route '/operations/reset'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\OperationalDataResetController::index
 * @see app/Http/Controllers/OperationalDataResetController.php:19
 * @route '/operations/reset'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\OperationalDataResetController::store
 * @see app/Http/Controllers/OperationalDataResetController.php:45
 * @route '/operations/reset'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/operations/reset',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\OperationalDataResetController::store
 * @see app/Http/Controllers/OperationalDataResetController.php:45
 * @route '/operations/reset'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\OperationalDataResetController::store
 * @see app/Http/Controllers/OperationalDataResetController.php:45
 * @route '/operations/reset'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\OperationalDataResetController::store
 * @see app/Http/Controllers/OperationalDataResetController.php:45
 * @route '/operations/reset'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\OperationalDataResetController::store
 * @see app/Http/Controllers/OperationalDataResetController.php:45
 * @route '/operations/reset'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const reset = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
}

export default reset