import reset from './reset'
const operations = {
    reset: Object.assign(reset, reset),
}

export default operations