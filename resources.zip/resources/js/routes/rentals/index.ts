import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import direct from './direct'
import checkout from './checkout'
import returnMethod from './return'
import financialCorrections from './financial-corrections'
import operationalCorrections from './operational-corrections'
/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:36
 * @route '/rentals'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/rentals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:36
 * @route '/rentals'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:36
 * @route '/rentals'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:36
 * @route '/rentals'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:36
 * @route '/rentals'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:36
 * @route '/rentals'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:36
 * @route '/rentals'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:262
 * @route '/rentals/{rental}'
 */
export const show = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/rentals/{rental}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:262
 * @route '/rentals/{rental}'
 */
show.url = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rental: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rental: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rental: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rental: typeof args.rental === 'object'
                ? args.rental.id
                : args.rental,
                }

    return show.definition.url
            .replace('{rental}', parsedArgs.rental.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:262
 * @route '/rentals/{rental}'
 */
show.get = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:262
 * @route '/rentals/{rental}'
 */
show.head = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:262
 * @route '/rentals/{rental}'
 */
    const showForm = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:262
 * @route '/rentals/{rental}'
 */
        showForm.get = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:262
 * @route '/rentals/{rental}'
 */
        showForm.head = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const rentals = {
    index: Object.assign(index, index),
direct: Object.assign(direct, direct),
checkout: Object.assign(checkout, checkout),
return: Object.assign(returnMethod, returnMethod),
financialCorrections: Object.assign(financialCorrections, financialCorrections),
operationalCorrections: Object.assign(operationalCorrections, operationalCorrections),
show: Object.assign(show, show),
}

export default rentals