import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:397
 * @route '/rentals/{rental}/financial-corrections'
 */
export const store = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/rentals/{rental}/financial-corrections',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:397
 * @route '/rentals/{rental}/financial-corrections'
 */
store.url = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rental: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rental: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rental: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rental: typeof args.rental === 'object'
                ? args.rental.id
                : args.rental,
                }

    return store.definition.url
            .replace('{rental}', parsedArgs.rental.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:397
 * @route '/rentals/{rental}/financial-corrections'
 */
store.post = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:397
 * @route '/rentals/{rental}/financial-corrections'
 */
    const storeForm = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:397
 * @route '/rentals/{rental}/financial-corrections'
 */
        storeForm.post = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const financialCorrections = {
    store: Object.assign(store, store),
}

export default financialCorrections