import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AssetCalendarController::assetCalendar
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
export const assetCalendar = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assetCalendar.url(args, options),
    method: 'get',
})

assetCalendar.definition = {
    methods: ["get","head"],
    url: '/rental/products/{slug}/asset-calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssetCalendarController::assetCalendar
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
assetCalendar.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return assetCalendar.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssetCalendarController::assetCalendar
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
assetCalendar.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: assetCalendar.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AssetCalendarController::assetCalendar
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
assetCalendar.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: assetCalendar.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AssetCalendarController::assetCalendar
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
    const assetCalendarForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: assetCalendar.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AssetCalendarController::assetCalendar
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
        assetCalendarForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: assetCalendar.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AssetCalendarController::assetCalendar
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
        assetCalendarForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: assetCalendar.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    assetCalendar.form = assetCalendarForm
/**
* @see \App\Http\Controllers\PublicCatalogController::show
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
export const show = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/rental/products/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogController::show
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
show.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return show.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogController::show
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
show.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogController::show
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
show.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogController::show
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
    const showForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogController::show
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
        showForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogController::show
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
        showForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const products = {
    assetCalendar: Object.assign(assetCalendar, assetCalendar),
show: Object.assign(show, show),
}

export default products