import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\CashSessionController::store
 * @see app/Http/Controllers/Finance/CashSessionController.php:16
 * @route '/finance/cash-registers/{cashRegister}/sessions'
 */
export const store = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/finance/cash-registers/{cashRegister}/sessions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\CashSessionController::store
 * @see app/Http/Controllers/Finance/CashSessionController.php:16
 * @route '/finance/cash-registers/{cashRegister}/sessions'
 */
store.url = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cashRegister: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cashRegister: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cashRegister: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cashRegister: typeof args.cashRegister === 'object'
                ? args.cashRegister.id
                : args.cashRegister,
                }

    return store.definition.url
            .replace('{cashRegister}', parsedArgs.cashRegister.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\CashSessionController::store
 * @see app/Http/Controllers/Finance/CashSessionController.php:16
 * @route '/finance/cash-registers/{cashRegister}/sessions'
 */
store.post = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\CashSessionController::store
 * @see app/Http/Controllers/Finance/CashSessionController.php:16
 * @route '/finance/cash-registers/{cashRegister}/sessions'
 */
    const storeForm = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\CashSessionController::store
 * @see app/Http/Controllers/Finance/CashSessionController.php:16
 * @route '/finance/cash-registers/{cashRegister}/sessions'
 */
        storeForm.post = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Finance\CashSessionController::close
 * @see app/Http/Controllers/Finance/CashSessionController.php:31
 * @route '/finance/cash-sessions/{cashSession}/close'
 */
export const close = (args: { cashSession: number | { id: number } } | [cashSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

close.definition = {
    methods: ["post"],
    url: '/finance/cash-sessions/{cashSession}/close',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\CashSessionController::close
 * @see app/Http/Controllers/Finance/CashSessionController.php:31
 * @route '/finance/cash-sessions/{cashSession}/close'
 */
close.url = (args: { cashSession: number | { id: number } } | [cashSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cashSession: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cashSession: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cashSession: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cashSession: typeof args.cashSession === 'object'
                ? args.cashSession.id
                : args.cashSession,
                }

    return close.definition.url
            .replace('{cashSession}', parsedArgs.cashSession.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\CashSessionController::close
 * @see app/Http/Controllers/Finance/CashSessionController.php:31
 * @route '/finance/cash-sessions/{cashSession}/close'
 */
close.post = (args: { cashSession: number | { id: number } } | [cashSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\CashSessionController::close
 * @see app/Http/Controllers/Finance/CashSessionController.php:31
 * @route '/finance/cash-sessions/{cashSession}/close'
 */
    const closeForm = (args: { cashSession: number | { id: number } } | [cashSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: close.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\CashSessionController::close
 * @see app/Http/Controllers/Finance/CashSessionController.php:31
 * @route '/finance/cash-sessions/{cashSession}/close'
 */
        closeForm.post = (args: { cashSession: number | { id: number } } | [cashSession: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: close.url(args, options),
            method: 'post',
        })
    
    close.form = closeForm
const cashSessions = {
    store: Object.assign(store, store),
close: Object.assign(close, close),
}

export default cashSessions