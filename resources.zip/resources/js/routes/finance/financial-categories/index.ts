import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::store
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:16
 * @route '/finance/financial-categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/finance/financial-categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::store
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:16
 * @route '/finance/financial-categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::store
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:16
 * @route '/finance/financial-categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::store
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:16
 * @route '/finance/financial-categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::store
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:16
 * @route '/finance/financial-categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::update
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:30
 * @route '/finance/financial-categories/{financialCategory}'
 */
export const update = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/finance/financial-categories/{financialCategory}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::update
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:30
 * @route '/finance/financial-categories/{financialCategory}'
 */
update.url = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { financialCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { financialCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    financialCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        financialCategory: typeof args.financialCategory === 'object'
                ? args.financialCategory.id
                : args.financialCategory,
                }

    return update.definition.url
            .replace('{financialCategory}', parsedArgs.financialCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::update
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:30
 * @route '/finance/financial-categories/{financialCategory}'
 */
update.put = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::update
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:30
 * @route '/finance/financial-categories/{financialCategory}'
 */
    const updateForm = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::update
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:30
 * @route '/finance/financial-categories/{financialCategory}'
 */
        updateForm.put = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::toggleStatus
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:50
 * @route '/finance/financial-categories/{financialCategory}/status'
 */
export const toggleStatus = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

toggleStatus.definition = {
    methods: ["patch"],
    url: '/finance/financial-categories/{financialCategory}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::toggleStatus
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:50
 * @route '/finance/financial-categories/{financialCategory}/status'
 */
toggleStatus.url = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { financialCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { financialCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    financialCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        financialCategory: typeof args.financialCategory === 'object'
                ? args.financialCategory.id
                : args.financialCategory,
                }

    return toggleStatus.definition.url
            .replace('{financialCategory}', parsedArgs.financialCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::toggleStatus
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:50
 * @route '/finance/financial-categories/{financialCategory}/status'
 */
toggleStatus.patch = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::toggleStatus
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:50
 * @route '/finance/financial-categories/{financialCategory}/status'
 */
    const toggleStatusForm = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\FinancialCategoryController::toggleStatus
 * @see app/Http/Controllers/Finance/FinancialCategoryController.php:50
 * @route '/finance/financial-categories/{financialCategory}/status'
 */
        toggleStatusForm.patch = (args: { financialCategory: number | { id: number } } | [financialCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleStatus.form = toggleStatusForm
const financialCategories = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
toggleStatus: Object.assign(toggleStatus, toggleStatus),
}

export default financialCategories