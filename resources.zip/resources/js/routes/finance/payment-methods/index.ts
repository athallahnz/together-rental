import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::store
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:16
 * @route '/finance/payment-methods'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/finance/payment-methods',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::store
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:16
 * @route '/finance/payment-methods'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::store
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:16
 * @route '/finance/payment-methods'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\PaymentMethodController::store
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:16
 * @route '/finance/payment-methods'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\PaymentMethodController::store
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:16
 * @route '/finance/payment-methods'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::update
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:30
 * @route '/finance/payment-methods/{paymentMethod}'
 */
export const update = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/finance/payment-methods/{paymentMethod}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::update
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:30
 * @route '/finance/payment-methods/{paymentMethod}'
 */
update.url = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { paymentMethod: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { paymentMethod: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    paymentMethod: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        paymentMethod: typeof args.paymentMethod === 'object'
                ? args.paymentMethod.id
                : args.paymentMethod,
                }

    return update.definition.url
            .replace('{paymentMethod}', parsedArgs.paymentMethod.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::update
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:30
 * @route '/finance/payment-methods/{paymentMethod}'
 */
update.put = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Finance\PaymentMethodController::update
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:30
 * @route '/finance/payment-methods/{paymentMethod}'
 */
    const updateForm = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\PaymentMethodController::update
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:30
 * @route '/finance/payment-methods/{paymentMethod}'
 */
        updateForm.put = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::toggleStatus
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:50
 * @route '/finance/payment-methods/{paymentMethod}/status'
 */
export const toggleStatus = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

toggleStatus.definition = {
    methods: ["patch"],
    url: '/finance/payment-methods/{paymentMethod}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::toggleStatus
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:50
 * @route '/finance/payment-methods/{paymentMethod}/status'
 */
toggleStatus.url = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { paymentMethod: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { paymentMethod: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    paymentMethod: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        paymentMethod: typeof args.paymentMethod === 'object'
                ? args.paymentMethod.id
                : args.paymentMethod,
                }

    return toggleStatus.definition.url
            .replace('{paymentMethod}', parsedArgs.paymentMethod.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\PaymentMethodController::toggleStatus
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:50
 * @route '/finance/payment-methods/{paymentMethod}/status'
 */
toggleStatus.patch = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Finance\PaymentMethodController::toggleStatus
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:50
 * @route '/finance/payment-methods/{paymentMethod}/status'
 */
    const toggleStatusForm = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\PaymentMethodController::toggleStatus
 * @see app/Http/Controllers/Finance/PaymentMethodController.php:50
 * @route '/finance/payment-methods/{paymentMethod}/status'
 */
        toggleStatusForm.patch = (args: { paymentMethod: number | { id: number } } | [paymentMethod: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleStatus.form = toggleStatusForm
const paymentMethods = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
toggleStatus: Object.assign(toggleStatus, toggleStatus),
}

export default paymentMethods