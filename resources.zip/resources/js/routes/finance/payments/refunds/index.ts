import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
export const store = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/finance/payments/{payment}/refunds',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
store.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return store.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
store.post = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
    const storeForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
        storeForm.post = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const refunds = {
    store: Object.assign(store, store),
}

export default refunds