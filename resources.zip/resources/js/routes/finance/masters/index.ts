import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/finance/master-data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const masters = {
    index: Object.assign(index, index),
}

export default masters