import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import masters from './masters'
import paymentMethods from './payment-methods'
import financialCategories from './financial-categories'
import cashRegisters from './cash-registers'
import payments from './payments'
import refunds from './refunds'
import cashSessions from './cash-sessions'
/**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/finance/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
const finance = {
    dashboard: Object.assign(dashboard, dashboard),
masters: Object.assign(masters, masters),
paymentMethods: Object.assign(paymentMethods, paymentMethods),
financialCategories: Object.assign(financialCategories, financialCategories),
cashRegisters: Object.assign(cashRegisters, cashRegisters),
payments: Object.assign(payments, payments),
refunds: Object.assign(refunds, refunds),
cashSessions: Object.assign(cashSessions, cashSessions),
}

export default finance