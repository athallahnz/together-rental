import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::resolve
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:41
 * @route '/transfers/{transfer}/items/{item}/resolve'
 */
export const resolve = (args: { transfer: number | { id: number }, item: number | { id: number } } | [transfer: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolve.url(args, options),
    method: 'post',
})

resolve.definition = {
    methods: ["post"],
    url: '/transfers/{transfer}/items/{item}/resolve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::resolve
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:41
 * @route '/transfers/{transfer}/items/{item}/resolve'
 */
resolve.url = (args: { transfer: number | { id: number }, item: number | { id: number } } | [transfer: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                    item: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                                item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return resolve.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::resolve
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:41
 * @route '/transfers/{transfer}/items/{item}/resolve'
 */
resolve.post = (args: { transfer: number | { id: number }, item: number | { id: number } } | [transfer: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::resolve
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:41
 * @route '/transfers/{transfer}/items/{item}/resolve'
 */
    const resolveForm = (args: { transfer: number | { id: number }, item: number | { id: number } } | [transfer: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resolve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::resolve
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:41
 * @route '/transfers/{transfer}/items/{item}/resolve'
 */
        resolveForm.post = (args: { transfer: number | { id: number }, item: number | { id: number } } | [transfer: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resolve.url(args, options),
            method: 'post',
        })
    
    resolve.form = resolveForm
const items = {
    resolve: Object.assign(resolve, resolve),
}

export default items