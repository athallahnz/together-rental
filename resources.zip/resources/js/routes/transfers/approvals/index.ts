import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Transfers\BranchTransferApprovalController::store
 * @see app/Http/Controllers/Transfers/BranchTransferApprovalController.php:16
 * @route '/transfers/{transfer}/approvals'
 */
export const store = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/transfers/{transfer}/approvals',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferApprovalController::store
 * @see app/Http/Controllers/Transfers/BranchTransferApprovalController.php:16
 * @route '/transfers/{transfer}/approvals'
 */
store.url = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transfer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transfer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                }

    return store.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferApprovalController::store
 * @see app/Http/Controllers/Transfers/BranchTransferApprovalController.php:16
 * @route '/transfers/{transfer}/approvals'
 */
store.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferApprovalController::store
 * @see app/Http/Controllers/Transfers/BranchTransferApprovalController.php:16
 * @route '/transfers/{transfer}/approvals'
 */
    const storeForm = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferApprovalController::store
 * @see app/Http/Controllers/Transfers/BranchTransferApprovalController.php:16
 * @route '/transfers/{transfer}/approvals'
 */
        storeForm.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const approvals = {
    store: Object.assign(store, store),
}

export default approvals