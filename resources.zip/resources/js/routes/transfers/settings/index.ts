import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:17
 * @route '/transfers/settings'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/transfers/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:17
 * @route '/transfers/settings'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:17
 * @route '/transfers/settings'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:17
 * @route '/transfers/settings'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:17
 * @route '/transfers/settings'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:17
 * @route '/transfers/settings'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:17
 * @route '/transfers/settings'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::update
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:35
 * @route '/transfers/settings'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/transfers/settings',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::update
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:35
 * @route '/transfers/settings'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::update
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:35
 * @route '/transfers/settings'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::update
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:35
 * @route '/transfers/settings'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferSettingsController::update
 * @see app/Http/Controllers/Transfers/BranchTransferSettingsController.php:35
 * @route '/transfers/settings'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const settings = {
    edit: Object.assign(edit, edit),
update: Object.assign(update, update),
}

export default settings