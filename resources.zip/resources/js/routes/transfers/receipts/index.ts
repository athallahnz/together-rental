import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::store
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:17
 * @route '/transfers/{transfer}/receipts'
 */
export const store = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/transfers/{transfer}/receipts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::store
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:17
 * @route '/transfers/{transfer}/receipts'
 */
store.url = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transfer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transfer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                }

    return store.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::store
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:17
 * @route '/transfers/{transfer}/receipts'
 */
store.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::store
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:17
 * @route '/transfers/{transfer}/receipts'
 */
    const storeForm = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferReceivingController::store
 * @see app/Http/Controllers/Transfers/BranchTransferReceivingController.php:17
 * @route '/transfers/{transfer}/receipts'
 */
        storeForm.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const receipts = {
    store: Object.assign(store, store),
}

export default receipts