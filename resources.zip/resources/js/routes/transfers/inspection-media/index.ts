import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
export const show = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/transfers/inspection-media/{media}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
show.url = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { media: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { media: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    media: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        media: typeof args.media === 'object'
                ? args.media.id
                : args.media,
                }

    return show.definition.url
            .replace('{media}', parsedArgs.media.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
show.get = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
show.head = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
    const showForm = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
        showForm.get = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
        showForm.head = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const inspectionMedia = {
    show: Object.assign(show, show),
}

export default inspectionMedia