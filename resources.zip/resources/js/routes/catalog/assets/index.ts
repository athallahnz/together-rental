import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AssetCalendarController::calendar
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
export const calendar = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calendar.url(args, options),
    method: 'get',
})

calendar.definition = {
    methods: ["get","head"],
    url: '/catalog/assets/{asset}/calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssetCalendarController::calendar
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
calendar.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return calendar.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssetCalendarController::calendar
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
calendar.get = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: calendar.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AssetCalendarController::calendar
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
calendar.head = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: calendar.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AssetCalendarController::calendar
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
    const calendarForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: calendar.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AssetCalendarController::calendar
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
        calendarForm.get = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calendar.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AssetCalendarController::calendar
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
        calendarForm.head = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: calendar.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    calendar.form = calendarForm
const assets = {
    calendar: Object.assign(calendar, calendar),
}

export default assets