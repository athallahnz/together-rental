import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\NotificationCenterController::update
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
export const update = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/notifications/rules/{notificationRule}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::update
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
update.url = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notificationRule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notificationRule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notificationRule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notificationRule: typeof args.notificationRule === 'object'
                ? args.notificationRule.id
                : args.notificationRule,
                }

    return update.definition.url
            .replace('{notificationRule}', parsedArgs.notificationRule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::update
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
update.put = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::update
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
    const updateForm = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::update
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
        updateForm.put = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const rules = {
    update: Object.assign(update, update),
}

export default rules