import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
import preferences from './preferences'
import rules from './rules'
/**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/notifications/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
export const markAllRead = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllRead.url(options),
    method: 'post',
})

markAllRead.definition = {
    methods: ["post"],
    url: '/notifications/mark-all-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
markAllRead.url = (options?: RouteQueryOptions) => {
    return markAllRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
markAllRead.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllRead.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
    const markAllReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAllRead.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
        markAllReadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAllRead.url(options),
            method: 'post',
        })
    
    markAllRead.form = markAllReadForm
/**
* @see \App\Http\Controllers\NotificationCenterController::read
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
export const read = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: read.url(args, options),
    method: 'patch',
})

read.definition = {
    methods: ["patch"],
    url: '/notifications/{notification}/read',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::read
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
read.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return read.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::read
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
read.patch = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: read.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::read
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
    const readForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: read.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::read
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
        readForm.patch = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: read.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    read.form = readForm
/**
* @see \App\Http\Controllers\NotificationCenterController::unread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
export const unread = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: unread.url(args, options),
    method: 'patch',
})

unread.definition = {
    methods: ["patch"],
    url: '/notifications/{notification}/unread',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::unread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
unread.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return unread.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::unread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
unread.patch = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: unread.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::unread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
    const unreadForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unread.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::unread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
        unreadForm.patch = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unread.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    unread.form = unreadForm
/**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
export const snooze = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: snooze.url(args, options),
    method: 'post',
})

snooze.definition = {
    methods: ["post"],
    url: '/notifications/{notification}/snooze',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
snooze.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return snooze.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
snooze.post = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: snooze.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
    const snoozeForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: snooze.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
        snoozeForm.post = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: snooze.url(args, options),
            method: 'post',
        })
    
    snooze.form = snoozeForm
/**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
export const dismiss = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: dismiss.url(args, options),
    method: 'delete',
})

dismiss.definition = {
    methods: ["delete"],
    url: '/notifications/{notification}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
dismiss.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return dismiss.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
dismiss.delete = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: dismiss.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
    const dismissForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: dismiss.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
        dismissForm.delete = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: dismiss.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    dismiss.form = dismissForm
const notifications = {
    index: Object.assign(index, index),
generate: Object.assign(generate, generate),
markAllRead: Object.assign(markAllRead, markAllRead),
preferences: Object.assign(preferences, preferences),
rules: Object.assign(rules, rules),
read: Object.assign(read, read),
unread: Object.assign(unread, unread),
snooze: Object.assign(snooze, snooze),
dismiss: Object.assign(dismiss, dismiss),
}

export default notifications