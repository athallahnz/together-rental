import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/notifications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\NotificationCenterController::index
 * @see app/Http/Controllers/NotificationCenterController.php:25
 * @route '/notifications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/notifications/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::generate
 * @see app/Http/Controllers/NotificationCenterController.php:253
 * @route '/notifications/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
export const markAllRead = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllRead.url(options),
    method: 'post',
})

markAllRead.definition = {
    methods: ["post"],
    url: '/notifications/mark-all-read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
markAllRead.url = (options?: RouteQueryOptions) => {
    return markAllRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
markAllRead.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllRead.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
    const markAllReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAllRead.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::markAllRead
 * @see app/Http/Controllers/NotificationCenterController.php:170
 * @route '/notifications/mark-all-read'
 */
        markAllReadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAllRead.url(options),
            method: 'post',
        })
    
    markAllRead.form = markAllReadForm
/**
* @see \App\Http\Controllers\NotificationCenterController::updatePreferences
 * @see app/Http/Controllers/NotificationCenterController.php:216
 * @route '/notifications/preferences'
 */
export const updatePreferences = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePreferences.url(options),
    method: 'put',
})

updatePreferences.definition = {
    methods: ["put"],
    url: '/notifications/preferences',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::updatePreferences
 * @see app/Http/Controllers/NotificationCenterController.php:216
 * @route '/notifications/preferences'
 */
updatePreferences.url = (options?: RouteQueryOptions) => {
    return updatePreferences.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::updatePreferences
 * @see app/Http/Controllers/NotificationCenterController.php:216
 * @route '/notifications/preferences'
 */
updatePreferences.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePreferences.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::updatePreferences
 * @see app/Http/Controllers/NotificationCenterController.php:216
 * @route '/notifications/preferences'
 */
    const updatePreferencesForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePreferences.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::updatePreferences
 * @see app/Http/Controllers/NotificationCenterController.php:216
 * @route '/notifications/preferences'
 */
        updatePreferencesForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePreferences.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePreferences.form = updatePreferencesForm
/**
* @see \App\Http\Controllers\NotificationCenterController::updateRule
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
export const updateRule = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateRule.url(args, options),
    method: 'put',
})

updateRule.definition = {
    methods: ["put"],
    url: '/notifications/rules/{notificationRule}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::updateRule
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
updateRule.url = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notificationRule: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notificationRule: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notificationRule: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notificationRule: typeof args.notificationRule === 'object'
                ? args.notificationRule.id
                : args.notificationRule,
                }

    return updateRule.definition.url
            .replace('{notificationRule}', parsedArgs.notificationRule.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::updateRule
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
updateRule.put = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateRule.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::updateRule
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
    const updateRuleForm = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateRule.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::updateRule
 * @see app/Http/Controllers/NotificationCenterController.php:230
 * @route '/notifications/rules/{notificationRule}'
 */
        updateRuleForm.put = (args: { notificationRule: number | { id: number } } | [notificationRule: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateRule.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateRule.form = updateRuleForm
/**
* @see \App\Http\Controllers\NotificationCenterController::markRead
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
export const markRead = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markRead.url(args, options),
    method: 'patch',
})

markRead.definition = {
    methods: ["patch"],
    url: '/notifications/{notification}/read',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::markRead
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
markRead.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return markRead.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::markRead
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
markRead.patch = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markRead.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::markRead
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
    const markReadForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markRead.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::markRead
 * @see app/Http/Controllers/NotificationCenterController.php:152
 * @route '/notifications/{notification}/read'
 */
        markReadForm.patch = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markRead.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    markRead.form = markReadForm
/**
* @see \App\Http\Controllers\NotificationCenterController::markUnread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
export const markUnread = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markUnread.url(args, options),
    method: 'patch',
})

markUnread.definition = {
    methods: ["patch"],
    url: '/notifications/{notification}/unread',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::markUnread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
markUnread.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return markUnread.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::markUnread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
markUnread.patch = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: markUnread.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::markUnread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
    const markUnreadForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markUnread.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::markUnread
 * @see app/Http/Controllers/NotificationCenterController.php:161
 * @route '/notifications/{notification}/unread'
 */
        markUnreadForm.patch = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markUnread.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    markUnread.form = markUnreadForm
/**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
export const snooze = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: snooze.url(args, options),
    method: 'post',
})

snooze.definition = {
    methods: ["post"],
    url: '/notifications/{notification}/snooze',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
snooze.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return snooze.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
snooze.post = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: snooze.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
    const snoozeForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: snooze.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::snooze
 * @see app/Http/Controllers/NotificationCenterController.php:187
 * @route '/notifications/{notification}/snooze'
 */
        snoozeForm.post = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: snooze.url(args, options),
            method: 'post',
        })
    
    snooze.form = snoozeForm
/**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
export const dismiss = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: dismiss.url(args, options),
    method: 'delete',
})

dismiss.definition = {
    methods: ["delete"],
    url: '/notifications/{notification}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
dismiss.url = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { notification: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { notification: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    notification: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        notification: typeof args.notification === 'object'
                ? args.notification.id
                : args.notification,
                }

    return dismiss.definition.url
            .replace('{notification}', parsedArgs.notification.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
dismiss.delete = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: dismiss.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
    const dismissForm = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: dismiss.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\NotificationCenterController::dismiss
 * @see app/Http/Controllers/NotificationCenterController.php:203
 * @route '/notifications/{notification}'
 */
        dismissForm.delete = (args: { notification: number | { id: number } } | [notification: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: dismiss.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    dismiss.form = dismissForm
const NotificationCenterController = { index, generate, markAllRead, updatePreferences, updateRule, markRead, markUnread, snooze, dismiss }

export default NotificationCenterController