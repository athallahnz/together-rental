import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\InventoryAuditController::index
 * @see app/Http/Controllers/InventoryAuditController.php:27
 * @route '/inventory-audits'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/inventory-audits',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::index
 * @see app/Http/Controllers/InventoryAuditController.php:27
 * @route '/inventory-audits'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::index
 * @see app/Http/Controllers/InventoryAuditController.php:27
 * @route '/inventory-audits'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InventoryAuditController::index
 * @see app/Http/Controllers/InventoryAuditController.php:27
 * @route '/inventory-audits'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::index
 * @see app/Http/Controllers/InventoryAuditController.php:27
 * @route '/inventory-audits'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::index
 * @see app/Http/Controllers/InventoryAuditController.php:27
 * @route '/inventory-audits'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InventoryAuditController::index
 * @see app/Http/Controllers/InventoryAuditController.php:27
 * @route '/inventory-audits'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\InventoryAuditController::store
 * @see app/Http/Controllers/InventoryAuditController.php:139
 * @route '/inventory-audits'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/inventory-audits',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::store
 * @see app/Http/Controllers/InventoryAuditController.php:139
 * @route '/inventory-audits'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::store
 * @see app/Http/Controllers/InventoryAuditController.php:139
 * @route '/inventory-audits'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::store
 * @see app/Http/Controllers/InventoryAuditController.php:139
 * @route '/inventory-audits'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::store
 * @see app/Http/Controllers/InventoryAuditController.php:139
 * @route '/inventory-audits'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\InventoryAuditController::media
 * @see app/Http/Controllers/InventoryAuditController.php:307
 * @route '/inventory-audits/media/{media}'
 */
export const media = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: media.url(args, options),
    method: 'get',
})

media.definition = {
    methods: ["get","head"],
    url: '/inventory-audits/media/{media}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::media
 * @see app/Http/Controllers/InventoryAuditController.php:307
 * @route '/inventory-audits/media/{media}'
 */
media.url = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { media: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { media: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    media: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        media: typeof args.media === 'object'
                ? args.media.id
                : args.media,
                }

    return media.definition.url
            .replace('{media}', parsedArgs.media.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::media
 * @see app/Http/Controllers/InventoryAuditController.php:307
 * @route '/inventory-audits/media/{media}'
 */
media.get = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: media.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InventoryAuditController::media
 * @see app/Http/Controllers/InventoryAuditController.php:307
 * @route '/inventory-audits/media/{media}'
 */
media.head = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: media.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::media
 * @see app/Http/Controllers/InventoryAuditController.php:307
 * @route '/inventory-audits/media/{media}'
 */
    const mediaForm = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: media.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::media
 * @see app/Http/Controllers/InventoryAuditController.php:307
 * @route '/inventory-audits/media/{media}'
 */
        mediaForm.get = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: media.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InventoryAuditController::media
 * @see app/Http/Controllers/InventoryAuditController.php:307
 * @route '/inventory-audits/media/{media}'
 */
        mediaForm.head = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: media.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    media.form = mediaForm
/**
* @see \App\Http\Controllers\InventoryAuditController::show
 * @see app/Http/Controllers/InventoryAuditController.php:74
 * @route '/inventory-audits/{inventoryAudit}'
 */
export const show = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/inventory-audits/{inventoryAudit}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::show
 * @see app/Http/Controllers/InventoryAuditController.php:74
 * @route '/inventory-audits/{inventoryAudit}'
 */
show.url = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inventoryAudit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { inventoryAudit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                }

    return show.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::show
 * @see app/Http/Controllers/InventoryAuditController.php:74
 * @route '/inventory-audits/{inventoryAudit}'
 */
show.get = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\InventoryAuditController::show
 * @see app/Http/Controllers/InventoryAuditController.php:74
 * @route '/inventory-audits/{inventoryAudit}'
 */
show.head = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::show
 * @see app/Http/Controllers/InventoryAuditController.php:74
 * @route '/inventory-audits/{inventoryAudit}'
 */
    const showForm = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::show
 * @see app/Http/Controllers/InventoryAuditController.php:74
 * @route '/inventory-audits/{inventoryAudit}'
 */
        showForm.get = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\InventoryAuditController::show
 * @see app/Http/Controllers/InventoryAuditController.php:74
 * @route '/inventory-audits/{inventoryAudit}'
 */
        showForm.head = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\InventoryAuditController::start
 * @see app/Http/Controllers/InventoryAuditController.php:156
 * @route '/inventory-audits/{inventoryAudit}/start'
 */
export const start = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/start',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::start
 * @see app/Http/Controllers/InventoryAuditController.php:156
 * @route '/inventory-audits/{inventoryAudit}/start'
 */
start.url = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inventoryAudit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { inventoryAudit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                }

    return start.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::start
 * @see app/Http/Controllers/InventoryAuditController.php:156
 * @route '/inventory-audits/{inventoryAudit}/start'
 */
start.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::start
 * @see app/Http/Controllers/InventoryAuditController.php:156
 * @route '/inventory-audits/{inventoryAudit}/start'
 */
    const startForm = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::start
 * @see app/Http/Controllers/InventoryAuditController.php:156
 * @route '/inventory-audits/{inventoryAudit}/start'
 */
        startForm.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(args, options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\InventoryAuditController::scan
 * @see app/Http/Controllers/InventoryAuditController.php:172
 * @route '/inventory-audits/{inventoryAudit}/scan'
 */
export const scan = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scan.url(args, options),
    method: 'post',
})

scan.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/scan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::scan
 * @see app/Http/Controllers/InventoryAuditController.php:172
 * @route '/inventory-audits/{inventoryAudit}/scan'
 */
scan.url = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inventoryAudit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { inventoryAudit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                }

    return scan.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::scan
 * @see app/Http/Controllers/InventoryAuditController.php:172
 * @route '/inventory-audits/{inventoryAudit}/scan'
 */
scan.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: scan.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::scan
 * @see app/Http/Controllers/InventoryAuditController.php:172
 * @route '/inventory-audits/{inventoryAudit}/scan'
 */
    const scanForm = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: scan.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::scan
 * @see app/Http/Controllers/InventoryAuditController.php:172
 * @route '/inventory-audits/{inventoryAudit}/scan'
 */
        scanForm.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: scan.url(args, options),
            method: 'post',
        })
    
    scan.form = scanForm
/**
* @see \App\Http\Controllers\InventoryAuditController::recordCount
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
export const recordCount = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recordCount.url(args, options),
    method: 'post',
})

recordCount.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/items/{item}/count',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::recordCount
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
recordCount.url = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                    item: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                                item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return recordCount.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::recordCount
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
recordCount.post = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: recordCount.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::recordCount
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
    const recordCountForm = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: recordCount.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::recordCount
 * @see app/Http/Controllers/InventoryAuditController.php:196
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/count'
 */
        recordCountForm.post = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: recordCount.url(args, options),
            method: 'post',
        })
    
    recordCount.form = recordCountForm
/**
* @see \App\Http\Controllers\InventoryAuditController::submit
 * @see app/Http/Controllers/InventoryAuditController.php:217
 * @route '/inventory-audits/{inventoryAudit}/submit'
 */
export const submit = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::submit
 * @see app/Http/Controllers/InventoryAuditController.php:217
 * @route '/inventory-audits/{inventoryAudit}/submit'
 */
submit.url = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inventoryAudit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { inventoryAudit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                }

    return submit.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::submit
 * @see app/Http/Controllers/InventoryAuditController.php:217
 * @route '/inventory-audits/{inventoryAudit}/submit'
 */
submit.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::submit
 * @see app/Http/Controllers/InventoryAuditController.php:217
 * @route '/inventory-audits/{inventoryAudit}/submit'
 */
    const submitForm = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::submit
 * @see app/Http/Controllers/InventoryAuditController.php:217
 * @route '/inventory-audits/{inventoryAudit}/submit'
 */
        submitForm.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
/**
* @see \App\Http\Controllers\InventoryAuditController::approve
 * @see app/Http/Controllers/InventoryAuditController.php:232
 * @route '/inventory-audits/{inventoryAudit}/approve'
 */
export const approve = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::approve
 * @see app/Http/Controllers/InventoryAuditController.php:232
 * @route '/inventory-audits/{inventoryAudit}/approve'
 */
approve.url = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inventoryAudit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { inventoryAudit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                }

    return approve.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::approve
 * @see app/Http/Controllers/InventoryAuditController.php:232
 * @route '/inventory-audits/{inventoryAudit}/approve'
 */
approve.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::approve
 * @see app/Http/Controllers/InventoryAuditController.php:232
 * @route '/inventory-audits/{inventoryAudit}/approve'
 */
    const approveForm = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::approve
 * @see app/Http/Controllers/InventoryAuditController.php:232
 * @route '/inventory-audits/{inventoryAudit}/approve'
 */
        approveForm.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
export const resolve = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolve.url(args, options),
    method: 'post',
})

resolve.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/items/{item}/resolve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
resolve.url = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                    item: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                                item: typeof args.item === 'object'
                ? args.item.id
                : args.item,
                }

    return resolve.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace('{item}', parsedArgs.item.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
resolve.post = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: resolve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
    const resolveForm = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: resolve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::resolve
 * @see app/Http/Controllers/InventoryAuditController.php:253
 * @route '/inventory-audits/{inventoryAudit}/items/{item}/resolve'
 */
        resolveForm.post = (args: { inventoryAudit: number | { id: number }, item: number | { id: number } } | [inventoryAudit: number | { id: number }, item: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: resolve.url(args, options),
            method: 'post',
        })
    
    resolve.form = resolveForm
/**
* @see \App\Http\Controllers\InventoryAuditController::close
 * @see app/Http/Controllers/InventoryAuditController.php:270
 * @route '/inventory-audits/{inventoryAudit}/close'
 */
export const close = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

close.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/close',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::close
 * @see app/Http/Controllers/InventoryAuditController.php:270
 * @route '/inventory-audits/{inventoryAudit}/close'
 */
close.url = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inventoryAudit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { inventoryAudit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                }

    return close.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::close
 * @see app/Http/Controllers/InventoryAuditController.php:270
 * @route '/inventory-audits/{inventoryAudit}/close'
 */
close.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::close
 * @see app/Http/Controllers/InventoryAuditController.php:270
 * @route '/inventory-audits/{inventoryAudit}/close'
 */
    const closeForm = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: close.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::close
 * @see app/Http/Controllers/InventoryAuditController.php:270
 * @route '/inventory-audits/{inventoryAudit}/close'
 */
        closeForm.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: close.url(args, options),
            method: 'post',
        })
    
    close.form = closeForm
/**
* @see \App\Http\Controllers\InventoryAuditController::cancel
 * @see app/Http/Controllers/InventoryAuditController.php:285
 * @route '/inventory-audits/{inventoryAudit}/cancel'
 */
export const cancel = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/inventory-audits/{inventoryAudit}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\InventoryAuditController::cancel
 * @see app/Http/Controllers/InventoryAuditController.php:285
 * @route '/inventory-audits/{inventoryAudit}/cancel'
 */
cancel.url = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { inventoryAudit: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { inventoryAudit: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    inventoryAudit: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        inventoryAudit: typeof args.inventoryAudit === 'object'
                ? args.inventoryAudit.id
                : args.inventoryAudit,
                }

    return cancel.definition.url
            .replace('{inventoryAudit}', parsedArgs.inventoryAudit.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\InventoryAuditController::cancel
 * @see app/Http/Controllers/InventoryAuditController.php:285
 * @route '/inventory-audits/{inventoryAudit}/cancel'
 */
cancel.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\InventoryAuditController::cancel
 * @see app/Http/Controllers/InventoryAuditController.php:285
 * @route '/inventory-audits/{inventoryAudit}/cancel'
 */
    const cancelForm = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\InventoryAuditController::cancel
 * @see app/Http/Controllers/InventoryAuditController.php:285
 * @route '/inventory-audits/{inventoryAudit}/cancel'
 */
        cancelForm.post = (args: { inventoryAudit: number | { id: number } } | [inventoryAudit: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
const InventoryAuditController = { index, store, media, show, start, scan, recordCount, submit, approve, resolve, close, cancel }

export default InventoryAuditController