import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AssetCalendarController::publicProduct
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
export const publicProduct = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: publicProduct.url(args, options),
    method: 'get',
})

publicProduct.definition = {
    methods: ["get","head"],
    url: '/rental/products/{slug}/asset-calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssetCalendarController::publicProduct
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
publicProduct.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return publicProduct.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssetCalendarController::publicProduct
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
publicProduct.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: publicProduct.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AssetCalendarController::publicProduct
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
publicProduct.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: publicProduct.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AssetCalendarController::publicProduct
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
    const publicProductForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: publicProduct.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AssetCalendarController::publicProduct
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
        publicProductForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: publicProduct.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AssetCalendarController::publicProduct
 * @see app/Http/Controllers/AssetCalendarController.php:51
 * @route '/rental/products/{slug}/asset-calendar'
 */
        publicProductForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: publicProduct.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    publicProduct.form = publicProductForm
/**
* @see \App\Http\Controllers\AssetCalendarController::show
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
export const show = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/catalog/assets/{asset}/calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\AssetCalendarController::show
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
show.url = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { asset: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { asset: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    asset: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        asset: typeof args.asset === 'object'
                ? args.asset.id
                : args.asset,
                }

    return show.definition.url
            .replace('{asset}', parsedArgs.asset.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AssetCalendarController::show
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
show.get = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\AssetCalendarController::show
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
show.head = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\AssetCalendarController::show
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
    const showForm = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\AssetCalendarController::show
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
        showForm.get = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\AssetCalendarController::show
 * @see app/Http/Controllers/AssetCalendarController.php:18
 * @route '/catalog/assets/{asset}/calendar'
 */
        showForm.head = (args: { asset: number | { id: number } } | [asset: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const AssetCalendarController = { publicProduct, show }

export default AssetCalendarController