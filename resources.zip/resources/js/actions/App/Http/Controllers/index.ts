import PublicCatalogController from './PublicCatalogController'
import PublicSitemapController from './PublicSitemapController'
import AssetCalendarController from './AssetCalendarController'
import DashboardController from './DashboardController'
import Finance from './Finance'
import CatalogController from './CatalogController'
import PublicCatalogContentController from './PublicCatalogContentController'
import CatalogIntelligenceController from './CatalogIntelligenceController'
import CatalogBrandController from './CatalogBrandController'
import ProductCategoryController from './ProductCategoryController'
import ProductController from './ProductController'
import ProductRateController from './ProductRateController'
import RatePlanController from './RatePlanController'
import RentalPackageController from './RentalPackageController'
import PackageItemController from './PackageItemController'
import PackageRateController from './PackageRateController'
import CustomerController from './CustomerController'
import CustomerIdentityController from './CustomerIdentityController'
import CustomerAddressController from './CustomerAddressController'
import CustomerLoyaltyController from './CustomerLoyaltyController'
import BookingController from './BookingController'
import RentalController from './RentalController'
import Transfers from './Transfers'
import OperationalDataResetController from './OperationalDataResetController'
import MaintenanceController from './MaintenanceController'
import InventoryAuditController from './InventoryAuditController'
import NotificationCenterController from './NotificationCenterController'
import UserManagementController from './UserManagementController'
import EmployeeController from './EmployeeController'
import PositionController from './PositionController'
import RoleController from './RoleController'
import BranchController from './BranchController'
import BranchPublicProfileController from './BranchPublicProfileController'
import IntegratedReportController from './IntegratedReportController'
import AssetAnalyticsController from './AssetAnalyticsController'
import LegacyImportController from './LegacyImportController'
import Settings from './Settings'
const Controllers = {
    PublicCatalogController: Object.assign(PublicCatalogController, PublicCatalogController),
PublicSitemapController: Object.assign(PublicSitemapController, PublicSitemapController),
AssetCalendarController: Object.assign(AssetCalendarController, AssetCalendarController),
DashboardController: Object.assign(DashboardController, DashboardController),
Finance: Object.assign(Finance, Finance),
CatalogController: Object.assign(CatalogController, CatalogController),
PublicCatalogContentController: Object.assign(PublicCatalogContentController, PublicCatalogContentController),
CatalogIntelligenceController: Object.assign(CatalogIntelligenceController, CatalogIntelligenceController),
CatalogBrandController: Object.assign(CatalogBrandController, CatalogBrandController),
ProductCategoryController: Object.assign(ProductCategoryController, ProductCategoryController),
ProductController: Object.assign(ProductController, ProductController),
ProductRateController: Object.assign(ProductRateController, ProductRateController),
RatePlanController: Object.assign(RatePlanController, RatePlanController),
RentalPackageController: Object.assign(RentalPackageController, RentalPackageController),
PackageItemController: Object.assign(PackageItemController, PackageItemController),
PackageRateController: Object.assign(PackageRateController, PackageRateController),
CustomerController: Object.assign(CustomerController, CustomerController),
CustomerIdentityController: Object.assign(CustomerIdentityController, CustomerIdentityController),
CustomerAddressController: Object.assign(CustomerAddressController, CustomerAddressController),
CustomerLoyaltyController: Object.assign(CustomerLoyaltyController, CustomerLoyaltyController),
BookingController: Object.assign(BookingController, BookingController),
RentalController: Object.assign(RentalController, RentalController),
Transfers: Object.assign(Transfers, Transfers),
OperationalDataResetController: Object.assign(OperationalDataResetController, OperationalDataResetController),
MaintenanceController: Object.assign(MaintenanceController, MaintenanceController),
InventoryAuditController: Object.assign(InventoryAuditController, InventoryAuditController),
NotificationCenterController: Object.assign(NotificationCenterController, NotificationCenterController),
UserManagementController: Object.assign(UserManagementController, UserManagementController),
EmployeeController: Object.assign(EmployeeController, EmployeeController),
PositionController: Object.assign(PositionController, PositionController),
RoleController: Object.assign(RoleController, RoleController),
BranchController: Object.assign(BranchController, BranchController),
BranchPublicProfileController: Object.assign(BranchPublicProfileController, BranchPublicProfileController),
IntegratedReportController: Object.assign(IntegratedReportController, IntegratedReportController),
AssetAnalyticsController: Object.assign(AssetAnalyticsController, AssetAnalyticsController),
LegacyImportController: Object.assign(LegacyImportController, LegacyImportController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers