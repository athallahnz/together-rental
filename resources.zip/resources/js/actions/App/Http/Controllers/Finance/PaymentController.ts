import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\PaymentController::index
 * @see app/Http/Controllers/Finance/PaymentController.php:25
 * @route '/finance/payments'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/finance/payments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\PaymentController::index
 * @see app/Http/Controllers/Finance/PaymentController.php:25
 * @route '/finance/payments'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\PaymentController::index
 * @see app/Http/Controllers/Finance/PaymentController.php:25
 * @route '/finance/payments'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\PaymentController::index
 * @see app/Http/Controllers/Finance/PaymentController.php:25
 * @route '/finance/payments'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\PaymentController::index
 * @see app/Http/Controllers/Finance/PaymentController.php:25
 * @route '/finance/payments'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\PaymentController::index
 * @see app/Http/Controllers/Finance/PaymentController.php:25
 * @route '/finance/payments'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\PaymentController::index
 * @see app/Http/Controllers/Finance/PaymentController.php:25
 * @route '/finance/payments'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Finance\PaymentController::show
 * @see app/Http/Controllers/Finance/PaymentController.php:167
 * @route '/finance/payments/{payment}'
 */
export const show = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/finance/payments/{payment}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\PaymentController::show
 * @see app/Http/Controllers/Finance/PaymentController.php:167
 * @route '/finance/payments/{payment}'
 */
show.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return show.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\PaymentController::show
 * @see app/Http/Controllers/Finance/PaymentController.php:167
 * @route '/finance/payments/{payment}'
 */
show.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\PaymentController::show
 * @see app/Http/Controllers/Finance/PaymentController.php:167
 * @route '/finance/payments/{payment}'
 */
show.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\PaymentController::show
 * @see app/Http/Controllers/Finance/PaymentController.php:167
 * @route '/finance/payments/{payment}'
 */
    const showForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\PaymentController::show
 * @see app/Http/Controllers/Finance/PaymentController.php:167
 * @route '/finance/payments/{payment}'
 */
        showForm.get = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\PaymentController::show
 * @see app/Http/Controllers/Finance/PaymentController.php:167
 * @route '/finance/payments/{payment}'
 */
        showForm.head = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Finance\PaymentController::voidMethod
 * @see app/Http/Controllers/Finance/PaymentController.php:239
 * @route '/finance/payments/{payment}/void'
 */
export const voidMethod = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voidMethod.url(args, options),
    method: 'post',
})

voidMethod.definition = {
    methods: ["post"],
    url: '/finance/payments/{payment}/void',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\PaymentController::voidMethod
 * @see app/Http/Controllers/Finance/PaymentController.php:239
 * @route '/finance/payments/{payment}/void'
 */
voidMethod.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return voidMethod.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\PaymentController::voidMethod
 * @see app/Http/Controllers/Finance/PaymentController.php:239
 * @route '/finance/payments/{payment}/void'
 */
voidMethod.post = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voidMethod.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\PaymentController::voidMethod
 * @see app/Http/Controllers/Finance/PaymentController.php:239
 * @route '/finance/payments/{payment}/void'
 */
    const voidMethodForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: voidMethod.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\PaymentController::voidMethod
 * @see app/Http/Controllers/Finance/PaymentController.php:239
 * @route '/finance/payments/{payment}/void'
 */
        voidMethodForm.post = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: voidMethod.url(args, options),
            method: 'post',
        })
    
    voidMethod.form = voidMethodForm
const PaymentController = { index, show, voidMethod, void: voidMethod }

export default PaymentController