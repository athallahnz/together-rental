import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
const FinanceDashboardController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: FinanceDashboardController.url(options),
    method: 'get',
})

FinanceDashboardController.definition = {
    methods: ["get","head"],
    url: '/finance/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
FinanceDashboardController.url = (options?: RouteQueryOptions) => {
    return FinanceDashboardController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
FinanceDashboardController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: FinanceDashboardController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
FinanceDashboardController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: FinanceDashboardController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
    const FinanceDashboardControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: FinanceDashboardController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
        FinanceDashboardControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: FinanceDashboardController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\FinanceDashboardController::__invoke
 * @see app/Http/Controllers/Finance/FinanceDashboardController.php:15
 * @route '/finance/dashboard'
 */
        FinanceDashboardControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: FinanceDashboardController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    FinanceDashboardController.form = FinanceDashboardControllerForm
export default FinanceDashboardController