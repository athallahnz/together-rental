import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
const FinanceMasterController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: FinanceMasterController.url(options),
    method: 'get',
})

FinanceMasterController.definition = {
    methods: ["get","head"],
    url: '/finance/master-data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
FinanceMasterController.url = (options?: RouteQueryOptions) => {
    return FinanceMasterController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
FinanceMasterController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: FinanceMasterController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
FinanceMasterController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: FinanceMasterController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
    const FinanceMasterControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: FinanceMasterController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
        FinanceMasterControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: FinanceMasterController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\FinanceMasterController::__invoke
 * @see app/Http/Controllers/Finance/FinanceMasterController.php:18
 * @route '/finance/master-data'
 */
        FinanceMasterControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: FinanceMasterController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    FinanceMasterController.form = FinanceMasterControllerForm
export default FinanceMasterController