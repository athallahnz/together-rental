import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
export const store = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/finance/payments/{payment}/refunds',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
store.url = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { payment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { payment: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    payment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        payment: typeof args.payment === 'object'
                ? args.payment.id
                : args.payment,
                }

    return store.definition.url
            .replace('{payment}', parsedArgs.payment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
store.post = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
    const storeForm = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::store
 * @see app/Http/Controllers/Finance/RefundController.php:206
 * @route '/finance/payments/{payment}/refunds'
 */
        storeForm.post = (args: { payment: number | { id: number } } | [payment: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Finance\RefundController::index
 * @see app/Http/Controllers/Finance/RefundController.php:33
 * @route '/finance/refunds'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/finance/refunds',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::index
 * @see app/Http/Controllers/Finance/RefundController.php:33
 * @route '/finance/refunds'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::index
 * @see app/Http/Controllers/Finance/RefundController.php:33
 * @route '/finance/refunds'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\RefundController::index
 * @see app/Http/Controllers/Finance/RefundController.php:33
 * @route '/finance/refunds'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::index
 * @see app/Http/Controllers/Finance/RefundController.php:33
 * @route '/finance/refunds'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::index
 * @see app/Http/Controllers/Finance/RefundController.php:33
 * @route '/finance/refunds'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\RefundController::index
 * @see app/Http/Controllers/Finance/RefundController.php:33
 * @route '/finance/refunds'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Finance\RefundController::show
 * @see app/Http/Controllers/Finance/RefundController.php:146
 * @route '/finance/refunds/{refund}'
 */
export const show = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/finance/refunds/{refund}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::show
 * @see app/Http/Controllers/Finance/RefundController.php:146
 * @route '/finance/refunds/{refund}'
 */
show.url = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { refund: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { refund: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    refund: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        refund: typeof args.refund === 'object'
                ? args.refund.id
                : args.refund,
                }

    return show.definition.url
            .replace('{refund}', parsedArgs.refund.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::show
 * @see app/Http/Controllers/Finance/RefundController.php:146
 * @route '/finance/refunds/{refund}'
 */
show.get = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\RefundController::show
 * @see app/Http/Controllers/Finance/RefundController.php:146
 * @route '/finance/refunds/{refund}'
 */
show.head = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::show
 * @see app/Http/Controllers/Finance/RefundController.php:146
 * @route '/finance/refunds/{refund}'
 */
    const showForm = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::show
 * @see app/Http/Controllers/Finance/RefundController.php:146
 * @route '/finance/refunds/{refund}'
 */
        showForm.get = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\RefundController::show
 * @see app/Http/Controllers/Finance/RefundController.php:146
 * @route '/finance/refunds/{refund}'
 */
        showForm.head = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Finance\RefundController::proof
 * @see app/Http/Controllers/Finance/RefundController.php:325
 * @route '/finance/refunds/{refund}/proof'
 */
export const proof = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: proof.url(args, options),
    method: 'get',
})

proof.definition = {
    methods: ["get","head"],
    url: '/finance/refunds/{refund}/proof',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::proof
 * @see app/Http/Controllers/Finance/RefundController.php:325
 * @route '/finance/refunds/{refund}/proof'
 */
proof.url = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { refund: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { refund: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    refund: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        refund: typeof args.refund === 'object'
                ? args.refund.id
                : args.refund,
                }

    return proof.definition.url
            .replace('{refund}', parsedArgs.refund.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::proof
 * @see app/Http/Controllers/Finance/RefundController.php:325
 * @route '/finance/refunds/{refund}/proof'
 */
proof.get = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: proof.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Finance\RefundController::proof
 * @see app/Http/Controllers/Finance/RefundController.php:325
 * @route '/finance/refunds/{refund}/proof'
 */
proof.head = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: proof.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::proof
 * @see app/Http/Controllers/Finance/RefundController.php:325
 * @route '/finance/refunds/{refund}/proof'
 */
    const proofForm = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: proof.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::proof
 * @see app/Http/Controllers/Finance/RefundController.php:325
 * @route '/finance/refunds/{refund}/proof'
 */
        proofForm.get = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: proof.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Finance\RefundController::proof
 * @see app/Http/Controllers/Finance/RefundController.php:325
 * @route '/finance/refunds/{refund}/proof'
 */
        proofForm.head = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: proof.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    proof.form = proofForm
/**
* @see \App\Http\Controllers\Finance\RefundController::approve
 * @see app/Http/Controllers/Finance/RefundController.php:227
 * @route '/finance/refunds/{refund}/approve'
 */
export const approve = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/finance/refunds/{refund}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::approve
 * @see app/Http/Controllers/Finance/RefundController.php:227
 * @route '/finance/refunds/{refund}/approve'
 */
approve.url = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { refund: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { refund: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    refund: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        refund: typeof args.refund === 'object'
                ? args.refund.id
                : args.refund,
                }

    return approve.definition.url
            .replace('{refund}', parsedArgs.refund.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::approve
 * @see app/Http/Controllers/Finance/RefundController.php:227
 * @route '/finance/refunds/{refund}/approve'
 */
approve.post = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::approve
 * @see app/Http/Controllers/Finance/RefundController.php:227
 * @route '/finance/refunds/{refund}/approve'
 */
    const approveForm = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::approve
 * @see app/Http/Controllers/Finance/RefundController.php:227
 * @route '/finance/refunds/{refund}/approve'
 */
        approveForm.post = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Finance\RefundController::reject
 * @see app/Http/Controllers/Finance/RefundController.php:244
 * @route '/finance/refunds/{refund}/reject'
 */
export const reject = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/finance/refunds/{refund}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::reject
 * @see app/Http/Controllers/Finance/RefundController.php:244
 * @route '/finance/refunds/{refund}/reject'
 */
reject.url = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { refund: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { refund: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    refund: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        refund: typeof args.refund === 'object'
                ? args.refund.id
                : args.refund,
                }

    return reject.definition.url
            .replace('{refund}', parsedArgs.refund.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::reject
 * @see app/Http/Controllers/Finance/RefundController.php:244
 * @route '/finance/refunds/{refund}/reject'
 */
reject.post = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::reject
 * @see app/Http/Controllers/Finance/RefundController.php:244
 * @route '/finance/refunds/{refund}/reject'
 */
    const rejectForm = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::reject
 * @see app/Http/Controllers/Finance/RefundController.php:244
 * @route '/finance/refunds/{refund}/reject'
 */
        rejectForm.post = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\Finance\RefundController::process
 * @see app/Http/Controllers/Finance/RefundController.php:265
 * @route '/finance/refunds/{refund}/process'
 */
export const process = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(args, options),
    method: 'post',
})

process.definition = {
    methods: ["post"],
    url: '/finance/refunds/{refund}/process',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::process
 * @see app/Http/Controllers/Finance/RefundController.php:265
 * @route '/finance/refunds/{refund}/process'
 */
process.url = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { refund: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { refund: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    refund: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        refund: typeof args.refund === 'object'
                ? args.refund.id
                : args.refund,
                }

    return process.definition.url
            .replace('{refund}', parsedArgs.refund.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::process
 * @see app/Http/Controllers/Finance/RefundController.php:265
 * @route '/finance/refunds/{refund}/process'
 */
process.post = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: process.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::process
 * @see app/Http/Controllers/Finance/RefundController.php:265
 * @route '/finance/refunds/{refund}/process'
 */
    const processForm = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: process.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::process
 * @see app/Http/Controllers/Finance/RefundController.php:265
 * @route '/finance/refunds/{refund}/process'
 */
        processForm.post = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: process.url(args, options),
            method: 'post',
        })
    
    process.form = processForm
/**
* @see \App\Http\Controllers\Finance\RefundController::cancel
 * @see app/Http/Controllers/Finance/RefundController.php:304
 * @route '/finance/refunds/{refund}/cancel'
 */
export const cancel = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/finance/refunds/{refund}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\RefundController::cancel
 * @see app/Http/Controllers/Finance/RefundController.php:304
 * @route '/finance/refunds/{refund}/cancel'
 */
cancel.url = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { refund: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { refund: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    refund: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        refund: typeof args.refund === 'object'
                ? args.refund.id
                : args.refund,
                }

    return cancel.definition.url
            .replace('{refund}', parsedArgs.refund.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\RefundController::cancel
 * @see app/Http/Controllers/Finance/RefundController.php:304
 * @route '/finance/refunds/{refund}/cancel'
 */
cancel.post = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\RefundController::cancel
 * @see app/Http/Controllers/Finance/RefundController.php:304
 * @route '/finance/refunds/{refund}/cancel'
 */
    const cancelForm = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\RefundController::cancel
 * @see app/Http/Controllers/Finance/RefundController.php:304
 * @route '/finance/refunds/{refund}/cancel'
 */
        cancelForm.post = (args: { refund: number | { id: number } } | [refund: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
const RefundController = { store, index, show, proof, approve, reject, process, cancel }

export default RefundController