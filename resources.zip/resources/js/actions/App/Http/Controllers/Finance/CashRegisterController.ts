import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Finance\CashRegisterController::store
 * @see app/Http/Controllers/Finance/CashRegisterController.php:16
 * @route '/finance/cash-registers'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/finance/cash-registers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Finance\CashRegisterController::store
 * @see app/Http/Controllers/Finance/CashRegisterController.php:16
 * @route '/finance/cash-registers'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\CashRegisterController::store
 * @see app/Http/Controllers/Finance/CashRegisterController.php:16
 * @route '/finance/cash-registers'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Finance\CashRegisterController::store
 * @see app/Http/Controllers/Finance/CashRegisterController.php:16
 * @route '/finance/cash-registers'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\CashRegisterController::store
 * @see app/Http/Controllers/Finance/CashRegisterController.php:16
 * @route '/finance/cash-registers'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Finance\CashRegisterController::update
 * @see app/Http/Controllers/Finance/CashRegisterController.php:37
 * @route '/finance/cash-registers/{cashRegister}'
 */
export const update = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/finance/cash-registers/{cashRegister}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Finance\CashRegisterController::update
 * @see app/Http/Controllers/Finance/CashRegisterController.php:37
 * @route '/finance/cash-registers/{cashRegister}'
 */
update.url = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cashRegister: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cashRegister: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cashRegister: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cashRegister: typeof args.cashRegister === 'object'
                ? args.cashRegister.id
                : args.cashRegister,
                }

    return update.definition.url
            .replace('{cashRegister}', parsedArgs.cashRegister.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\CashRegisterController::update
 * @see app/Http/Controllers/Finance/CashRegisterController.php:37
 * @route '/finance/cash-registers/{cashRegister}'
 */
update.put = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Finance\CashRegisterController::update
 * @see app/Http/Controllers/Finance/CashRegisterController.php:37
 * @route '/finance/cash-registers/{cashRegister}'
 */
    const updateForm = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\CashRegisterController::update
 * @see app/Http/Controllers/Finance/CashRegisterController.php:37
 * @route '/finance/cash-registers/{cashRegister}'
 */
        updateForm.put = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Finance\CashRegisterController::toggleStatus
 * @see app/Http/Controllers/Finance/CashRegisterController.php:64
 * @route '/finance/cash-registers/{cashRegister}/status'
 */
export const toggleStatus = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

toggleStatus.definition = {
    methods: ["patch"],
    url: '/finance/cash-registers/{cashRegister}/status',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\Finance\CashRegisterController::toggleStatus
 * @see app/Http/Controllers/Finance/CashRegisterController.php:64
 * @route '/finance/cash-registers/{cashRegister}/status'
 */
toggleStatus.url = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { cashRegister: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { cashRegister: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    cashRegister: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        cashRegister: typeof args.cashRegister === 'object'
                ? args.cashRegister.id
                : args.cashRegister,
                }

    return toggleStatus.definition.url
            .replace('{cashRegister}', parsedArgs.cashRegister.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Finance\CashRegisterController::toggleStatus
 * @see app/Http/Controllers/Finance/CashRegisterController.php:64
 * @route '/finance/cash-registers/{cashRegister}/status'
 */
toggleStatus.patch = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: toggleStatus.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Finance\CashRegisterController::toggleStatus
 * @see app/Http/Controllers/Finance/CashRegisterController.php:64
 * @route '/finance/cash-registers/{cashRegister}/status'
 */
    const toggleStatusForm = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStatus.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Finance\CashRegisterController::toggleStatus
 * @see app/Http/Controllers/Finance/CashRegisterController.php:64
 * @route '/finance/cash-registers/{cashRegister}/status'
 */
        toggleStatusForm.patch = (args: { cashRegister: number | { id: number } } | [cashRegister: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStatus.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    toggleStatus.form = toggleStatusForm
const CashRegisterController = { store, update, toggleStatus }

export default CashRegisterController