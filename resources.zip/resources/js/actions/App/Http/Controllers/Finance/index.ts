import FinanceDashboardController from './FinanceDashboardController'
import FinanceMasterController from './FinanceMasterController'
import PaymentMethodController from './PaymentMethodController'
import FinancialCategoryController from './FinancialCategoryController'
import CashRegisterController from './CashRegisterController'
import PaymentController from './PaymentController'
import RefundController from './RefundController'
import CashSessionController from './CashSessionController'
const Finance = {
    FinanceDashboardController: Object.assign(FinanceDashboardController, FinanceDashboardController),
FinanceMasterController: Object.assign(FinanceMasterController, FinanceMasterController),
PaymentMethodController: Object.assign(PaymentMethodController, PaymentMethodController),
FinancialCategoryController: Object.assign(FinancialCategoryController, FinancialCategoryController),
CashRegisterController: Object.assign(CashRegisterController, CashRegisterController),
PaymentController: Object.assign(PaymentController, PaymentController),
RefundController: Object.assign(RefundController, RefundController),
CashSessionController: Object.assign(CashSessionController, CashSessionController),
}

export default Finance