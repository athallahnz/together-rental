import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:15
 * @route '/transfers/documents/{document}'
 */
export const show = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/transfers/documents/{document}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:15
 * @route '/transfers/documents/{document}'
 */
show.url = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { document: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { document: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    document: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return show.definition.url
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:15
 * @route '/transfers/documents/{document}'
 */
show.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:15
 * @route '/transfers/documents/{document}'
 */
show.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:15
 * @route '/transfers/documents/{document}'
 */
    const showForm = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:15
 * @route '/transfers/documents/{document}'
 */
        showForm.get = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::show
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:15
 * @route '/transfers/documents/{document}'
 */
        showForm.head = (args: { document: number | { id: number } } | [document: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::inspectionMedia
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
export const inspectionMedia = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: inspectionMedia.url(args, options),
    method: 'get',
})

inspectionMedia.definition = {
    methods: ["get","head"],
    url: '/transfers/inspection-media/{media}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::inspectionMedia
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
inspectionMedia.url = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { media: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { media: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    media: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        media: typeof args.media === 'object'
                ? args.media.id
                : args.media,
                }

    return inspectionMedia.definition.url
            .replace('{media}', parsedArgs.media.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::inspectionMedia
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
inspectionMedia.get = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: inspectionMedia.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::inspectionMedia
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
inspectionMedia.head = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: inspectionMedia.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::inspectionMedia
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
    const inspectionMediaForm = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: inspectionMedia.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::inspectionMedia
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
        inspectionMediaForm.get = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: inspectionMedia.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferDocumentController::inspectionMedia
 * @see app/Http/Controllers/Transfers/BranchTransferDocumentController.php:33
 * @route '/transfers/inspection-media/{media}'
 */
        inspectionMediaForm.head = (args: { media: number | { id: number } } | [media: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: inspectionMedia.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    inspectionMedia.form = inspectionMediaForm
const BranchTransferDocumentController = { show, inspectionMedia }

export default BranchTransferDocumentController