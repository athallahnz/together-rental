import BranchTransferSettingsController from './BranchTransferSettingsController'
import BranchTransferController from './BranchTransferController'
import BranchTransferDocumentController from './BranchTransferDocumentController'
import BranchTransferApprovalController from './BranchTransferApprovalController'
import BranchTransferDispatchController from './BranchTransferDispatchController'
import BranchTransferReceivingController from './BranchTransferReceivingController'
import BranchTransferExpenseController from './BranchTransferExpenseController'
const Transfers = {
    BranchTransferSettingsController: Object.assign(BranchTransferSettingsController, BranchTransferSettingsController),
BranchTransferController: Object.assign(BranchTransferController, BranchTransferController),
BranchTransferDocumentController: Object.assign(BranchTransferDocumentController, BranchTransferDocumentController),
BranchTransferApprovalController: Object.assign(BranchTransferApprovalController, BranchTransferApprovalController),
BranchTransferDispatchController: Object.assign(BranchTransferDispatchController, BranchTransferDispatchController),
BranchTransferReceivingController: Object.assign(BranchTransferReceivingController, BranchTransferReceivingController),
BranchTransferExpenseController: Object.assign(BranchTransferExpenseController, BranchTransferExpenseController),
}

export default Transfers