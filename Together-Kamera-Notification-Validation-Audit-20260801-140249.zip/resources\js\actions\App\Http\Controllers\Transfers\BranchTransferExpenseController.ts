import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::store
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:17
 * @route '/transfers/{transfer}/expenses'
 */
export const store = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/transfers/{transfer}/expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::store
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:17
 * @route '/transfers/{transfer}/expenses'
 */
store.url = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transfer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transfer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                }

    return store.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::store
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:17
 * @route '/transfers/{transfer}/expenses'
 */
store.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::store
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:17
 * @route '/transfers/{transfer}/expenses'
 */
    const storeForm = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::store
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:17
 * @route '/transfers/{transfer}/expenses'
 */
        storeForm.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::update
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:33
 * @route '/transfers/{transfer}/expenses/{expense}'
 */
export const update = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/transfers/{transfer}/expenses/{expense}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::update
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:33
 * @route '/transfers/{transfer}/expenses/{expense}'
 */
update.url = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return update.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::update
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:33
 * @route '/transfers/{transfer}/expenses/{expense}'
 */
update.put = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::update
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:33
 * @route '/transfers/{transfer}/expenses/{expense}'
 */
    const updateForm = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::update
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:33
 * @route '/transfers/{transfer}/expenses/{expense}'
 */
        updateForm.put = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::pay
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:49
 * @route '/transfers/{transfer}/expenses/{expense}/pay'
 */
export const pay = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

pay.definition = {
    methods: ["post"],
    url: '/transfers/{transfer}/expenses/{expense}/pay',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::pay
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:49
 * @route '/transfers/{transfer}/expenses/{expense}/pay'
 */
pay.url = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return pay.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::pay
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:49
 * @route '/transfers/{transfer}/expenses/{expense}/pay'
 */
pay.post = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: pay.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::pay
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:49
 * @route '/transfers/{transfer}/expenses/{expense}/pay'
 */
    const payForm = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: pay.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::pay
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:49
 * @route '/transfers/{transfer}/expenses/{expense}/pay'
 */
        payForm.post = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: pay.url(args, options),
            method: 'post',
        })
    
    pay.form = payForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::voidMethod
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:66
 * @route '/transfers/{transfer}/expenses/{expense}/void'
 */
export const voidMethod = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voidMethod.url(args, options),
    method: 'post',
})

voidMethod.definition = {
    methods: ["post"],
    url: '/transfers/{transfer}/expenses/{expense}/void',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::voidMethod
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:66
 * @route '/transfers/{transfer}/expenses/{expense}/void'
 */
voidMethod.url = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                    expense: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                                expense: typeof args.expense === 'object'
                ? args.expense.id
                : args.expense,
                }

    return voidMethod.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace('{expense}', parsedArgs.expense.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::voidMethod
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:66
 * @route '/transfers/{transfer}/expenses/{expense}/void'
 */
voidMethod.post = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: voidMethod.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::voidMethod
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:66
 * @route '/transfers/{transfer}/expenses/{expense}/void'
 */
    const voidMethodForm = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: voidMethod.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferExpenseController::voidMethod
 * @see app/Http/Controllers/Transfers/BranchTransferExpenseController.php:66
 * @route '/transfers/{transfer}/expenses/{expense}/void'
 */
        voidMethodForm.post = (args: { transfer: number | { id: number }, expense: number | { id: number } } | [transfer: number | { id: number }, expense: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: voidMethod.url(args, options),
            method: 'post',
        })
    
    voidMethod.form = voidMethodForm
const BranchTransferExpenseController = { store, update, pay, voidMethod, void: voidMethod }

export default BranchTransferExpenseController