import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::index
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:32
 * @route '/transfers'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/transfers',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::index
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:32
 * @route '/transfers'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::index
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:32
 * @route '/transfers'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::index
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:32
 * @route '/transfers'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::index
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:32
 * @route '/transfers'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::index
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:32
 * @route '/transfers'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::index
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:32
 * @route '/transfers'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::create
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:90
 * @route '/transfers/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/transfers/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::create
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:90
 * @route '/transfers/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::create
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:90
 * @route '/transfers/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::create
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:90
 * @route '/transfers/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::create
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:90
 * @route '/transfers/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::create
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:90
 * @route '/transfers/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::create
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:90
 * @route '/transfers/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::store
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:105
 * @route '/transfers'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/transfers',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::store
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:105
 * @route '/transfers'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::store
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:105
 * @route '/transfers'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::store
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:105
 * @route '/transfers'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::store
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:105
 * @route '/transfers'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::options
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:389
 * @route '/transfers/options'
 */
export const options = (routeOptions?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: options.url(routeOptions),
    method: 'get',
})

options.definition = {
    methods: ["get","head"],
    url: '/transfers/options',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::options
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:389
 * @route '/transfers/options'
 */
options.url = (routeOptions?: RouteQueryOptions) => {
    return options.definition.url
 + queryParams(routeOptions)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::options
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:389
 * @route '/transfers/options'
 */
options.get = (routeOptions?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: options.url(routeOptions),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::options
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:389
 * @route '/transfers/options'
 */
options.head = (routeOptions?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: options.url(routeOptions),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::options
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:389
 * @route '/transfers/options'
 */
    const optionsForm = (routeOptions?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: options.url(
            
                            routeOptions
                   ),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::options
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:389
 * @route '/transfers/options'
 */
        optionsForm.get = (routeOptions?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: options.url(
                
                                routeOptions
                           ),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::options
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:389
 * @route '/transfers/options'
 */
        optionsForm.head = (routeOptions?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: options.url({
                        [routeOptions?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(routeOptions?.query ?? routeOptions?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    options.form = optionsForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::preflight
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:351
 * @route '/transfers/preflight'
 */
export const preflight = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preflight.url(options),
    method: 'post',
})

preflight.definition = {
    methods: ["post"],
    url: '/transfers/preflight',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::preflight
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:351
 * @route '/transfers/preflight'
 */
preflight.url = (options?: RouteQueryOptions) => {
    return preflight.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::preflight
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:351
 * @route '/transfers/preflight'
 */
preflight.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preflight.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::preflight
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:351
 * @route '/transfers/preflight'
 */
    const preflightForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: preflight.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::preflight
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:351
 * @route '/transfers/preflight'
 */
        preflightForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: preflight.url(options),
            method: 'post',
        })
    
    preflight.form = preflightForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::show
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:162
 * @route '/transfers/{transfer}'
 */
export const show = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/transfers/{transfer}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::show
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:162
 * @route '/transfers/{transfer}'
 */
show.url = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transfer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transfer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                }

    return show.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::show
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:162
 * @route '/transfers/{transfer}'
 */
show.get = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::show
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:162
 * @route '/transfers/{transfer}'
 */
show.head = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::show
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:162
 * @route '/transfers/{transfer}'
 */
    const showForm = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::show
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:162
 * @route '/transfers/{transfer}'
 */
        showForm.get = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::show
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:162
 * @route '/transfers/{transfer}'
 */
        showForm.head = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:217
 * @route '/transfers/{transfer}/edit'
 */
export const edit = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/transfers/{transfer}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:217
 * @route '/transfers/{transfer}/edit'
 */
edit.url = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transfer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transfer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                }

    return edit.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:217
 * @route '/transfers/{transfer}/edit'
 */
edit.get = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:217
 * @route '/transfers/{transfer}/edit'
 */
edit.head = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:217
 * @route '/transfers/{transfer}/edit'
 */
    const editForm = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:217
 * @route '/transfers/{transfer}/edit'
 */
        editForm.get = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::edit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:217
 * @route '/transfers/{transfer}/edit'
 */
        editForm.head = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::update
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:237
 * @route '/transfers/{transfer}'
 */
export const update = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/transfers/{transfer}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::update
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:237
 * @route '/transfers/{transfer}'
 */
update.url = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transfer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transfer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                }

    return update.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::update
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:237
 * @route '/transfers/{transfer}'
 */
update.put = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::update
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:237
 * @route '/transfers/{transfer}'
 */
    const updateForm = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::update
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:237
 * @route '/transfers/{transfer}'
 */
        updateForm.put = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::submit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:290
 * @route '/transfers/{transfer}/submit'
 */
export const submit = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/transfers/{transfer}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::submit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:290
 * @route '/transfers/{transfer}/submit'
 */
submit.url = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transfer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transfer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                }

    return submit.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::submit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:290
 * @route '/transfers/{transfer}/submit'
 */
submit.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::submit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:290
 * @route '/transfers/{transfer}/submit'
 */
    const submitForm = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::submit
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:290
 * @route '/transfers/{transfer}/submit'
 */
        submitForm.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::cancel
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:334
 * @route '/transfers/{transfer}/cancel'
 */
export const cancel = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

cancel.definition = {
    methods: ["post"],
    url: '/transfers/{transfer}/cancel',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::cancel
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:334
 * @route '/transfers/{transfer}/cancel'
 */
cancel.url = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { transfer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { transfer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    transfer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        transfer: typeof args.transfer === 'object'
                ? args.transfer.id
                : args.transfer,
                }

    return cancel.definition.url
            .replace('{transfer}', parsedArgs.transfer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Transfers\BranchTransferController::cancel
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:334
 * @route '/transfers/{transfer}/cancel'
 */
cancel.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: cancel.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::cancel
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:334
 * @route '/transfers/{transfer}/cancel'
 */
    const cancelForm = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: cancel.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Transfers\BranchTransferController::cancel
 * @see app/Http/Controllers/Transfers/BranchTransferController.php:334
 * @route '/transfers/{transfer}/cancel'
 */
        cancelForm.post = (args: { transfer: number | { id: number } } | [transfer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: cancel.url(args, options),
            method: 'post',
        })
    
    cancel.form = cancelForm
const BranchTransferController = { index, create, store, options, preflight, show, edit, update, submit, cancel }

export default BranchTransferController