import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerLoyaltyController::store
 * @see app/Http/Controllers/CustomerLoyaltyController.php:14
 * @route '/customers/{customer}/loyalty-adjustments'
 */
export const store = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/customers/{customer}/loyalty-adjustments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CustomerLoyaltyController::store
 * @see app/Http/Controllers/CustomerLoyaltyController.php:14
 * @route '/customers/{customer}/loyalty-adjustments'
 */
store.url = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customer: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customer: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customer: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customer: typeof args.customer === 'object'
                ? args.customer.id
                : args.customer,
                }

    return store.definition.url
            .replace('{customer}', parsedArgs.customer.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerLoyaltyController::store
 * @see app/Http/Controllers/CustomerLoyaltyController.php:14
 * @route '/customers/{customer}/loyalty-adjustments'
 */
store.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CustomerLoyaltyController::store
 * @see app/Http/Controllers/CustomerLoyaltyController.php:14
 * @route '/customers/{customer}/loyalty-adjustments'
 */
    const storeForm = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CustomerLoyaltyController::store
 * @see app/Http/Controllers/CustomerLoyaltyController.php:14
 * @route '/customers/{customer}/loyalty-adjustments'
 */
        storeForm.post = (args: { customer: number | { id: number } } | [customer: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const loyalty = {
    store: Object.assign(store, store),
}

export default loyalty