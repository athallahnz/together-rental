import visual from './visual'
import logo from './logo'
const brands = {
    visual: Object.assign(visual, visual),
logo: Object.assign(logo, logo),
}

export default brands