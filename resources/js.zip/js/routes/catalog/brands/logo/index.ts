import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CatalogBrandController::destroy
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
export const destroy = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/catalog/brands/{catalogBrand}/logo',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CatalogBrandController::destroy
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
destroy.url = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { catalogBrand: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { catalogBrand: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    catalogBrand: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        catalogBrand: typeof args.catalogBrand === 'object'
                ? args.catalogBrand.id
                : args.catalogBrand,
                }

    return destroy.definition.url
            .replace('{catalogBrand}', parsedArgs.catalogBrand.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogBrandController::destroy
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
destroy.delete = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CatalogBrandController::destroy
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
    const destroyForm = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogBrandController::destroy
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
        destroyForm.delete = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const logo = {
    destroy: Object.assign(destroy, destroy),
}

export default logo