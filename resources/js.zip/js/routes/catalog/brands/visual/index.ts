import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CatalogBrandController::update
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
export const update = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/catalog/brands/{catalogBrand}/visual',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CatalogBrandController::update
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
update.url = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { catalogBrand: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { catalogBrand: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    catalogBrand: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        catalogBrand: typeof args.catalogBrand === 'object'
                ? args.catalogBrand.id
                : args.catalogBrand,
                }

    return update.definition.url
            .replace('{catalogBrand}', parsedArgs.catalogBrand.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogBrandController::update
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
update.post = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CatalogBrandController::update
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
    const updateForm = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogBrandController::update
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
        updateForm.post = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, options),
            method: 'post',
        })
    
    update.form = updateForm
const visual = {
    update: Object.assign(update, update),
}

export default visual