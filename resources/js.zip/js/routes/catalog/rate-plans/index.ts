import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\RatePlanController::store
 * @see app/Http/Controllers/RatePlanController.php:13
 * @route '/catalog/rate-plans'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/catalog/rate-plans',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RatePlanController::store
 * @see app/Http/Controllers/RatePlanController.php:13
 * @route '/catalog/rate-plans'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RatePlanController::store
 * @see app/Http/Controllers/RatePlanController.php:13
 * @route '/catalog/rate-plans'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RatePlanController::store
 * @see app/Http/Controllers/RatePlanController.php:13
 * @route '/catalog/rate-plans'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RatePlanController::store
 * @see app/Http/Controllers/RatePlanController.php:13
 * @route '/catalog/rate-plans'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RatePlanController::update
 * @see app/Http/Controllers/RatePlanController.php:36
 * @route '/catalog/rate-plans/{ratePlan}'
 */
export const update = (args: { ratePlan: number | { id: number } } | [ratePlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/catalog/rate-plans/{ratePlan}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RatePlanController::update
 * @see app/Http/Controllers/RatePlanController.php:36
 * @route '/catalog/rate-plans/{ratePlan}'
 */
update.url = (args: { ratePlan: number | { id: number } } | [ratePlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ratePlan: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ratePlan: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ratePlan: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ratePlan: typeof args.ratePlan === 'object'
                ? args.ratePlan.id
                : args.ratePlan,
                }

    return update.definition.url
            .replace('{ratePlan}', parsedArgs.ratePlan.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RatePlanController::update
 * @see app/Http/Controllers/RatePlanController.php:36
 * @route '/catalog/rate-plans/{ratePlan}'
 */
update.put = (args: { ratePlan: number | { id: number } } | [ratePlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\RatePlanController::update
 * @see app/Http/Controllers/RatePlanController.php:36
 * @route '/catalog/rate-plans/{ratePlan}'
 */
    const updateForm = (args: { ratePlan: number | { id: number } } | [ratePlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RatePlanController::update
 * @see app/Http/Controllers/RatePlanController.php:36
 * @route '/catalog/rate-plans/{ratePlan}'
 */
        updateForm.put = (args: { ratePlan: number | { id: number } } | [ratePlan: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const ratePlans = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
}

export default ratePlans