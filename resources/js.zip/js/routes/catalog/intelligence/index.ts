import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import candidates from './candidates'
/**
* @see \App\Http\Controllers\CatalogIntelligenceController::index
 * @see app/Http/Controllers/CatalogIntelligenceController.php:21
 * @route '/catalog/intelligence'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/catalog/intelligence',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::index
 * @see app/Http/Controllers/CatalogIntelligenceController.php:21
 * @route '/catalog/intelligence'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::index
 * @see app/Http/Controllers/CatalogIntelligenceController.php:21
 * @route '/catalog/intelligence'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CatalogIntelligenceController::index
 * @see app/Http/Controllers/CatalogIntelligenceController.php:21
 * @route '/catalog/intelligence'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CatalogIntelligenceController::index
 * @see app/Http/Controllers/CatalogIntelligenceController.php:21
 * @route '/catalog/intelligence'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CatalogIntelligenceController::index
 * @see app/Http/Controllers/CatalogIntelligenceController.php:21
 * @route '/catalog/intelligence'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CatalogIntelligenceController::index
 * @see app/Http/Controllers/CatalogIntelligenceController.php:21
 * @route '/catalog/intelligence'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CatalogIntelligenceController::generate
 * @see app/Http/Controllers/CatalogIntelligenceController.php:91
 * @route '/catalog/intelligence/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/catalog/intelligence/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::generate
 * @see app/Http/Controllers/CatalogIntelligenceController.php:91
 * @route '/catalog/intelligence/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::generate
 * @see app/Http/Controllers/CatalogIntelligenceController.php:91
 * @route '/catalog/intelligence/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CatalogIntelligenceController::generate
 * @see app/Http/Controllers/CatalogIntelligenceController.php:91
 * @route '/catalog/intelligence/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogIntelligenceController::generate
 * @see app/Http/Controllers/CatalogIntelligenceController.php:91
 * @route '/catalog/intelligence/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
/**
* @see \App\Http\Controllers\CatalogIntelligenceController::approveHighConfidence
 * @see app/Http/Controllers/CatalogIntelligenceController.php:150
 * @route '/catalog/intelligence/runs/{run}/approve-high-confidence'
 */
export const approveHighConfidence = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveHighConfidence.url(args, options),
    method: 'post',
})

approveHighConfidence.definition = {
    methods: ["post"],
    url: '/catalog/intelligence/runs/{run}/approve-high-confidence',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::approveHighConfidence
 * @see app/Http/Controllers/CatalogIntelligenceController.php:150
 * @route '/catalog/intelligence/runs/{run}/approve-high-confidence'
 */
approveHighConfidence.url = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { run: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { run: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    run: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        run: typeof args.run === 'object'
                ? args.run.id
                : args.run,
                }

    return approveHighConfidence.definition.url
            .replace('{run}', parsedArgs.run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::approveHighConfidence
 * @see app/Http/Controllers/CatalogIntelligenceController.php:150
 * @route '/catalog/intelligence/runs/{run}/approve-high-confidence'
 */
approveHighConfidence.post = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveHighConfidence.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CatalogIntelligenceController::approveHighConfidence
 * @see app/Http/Controllers/CatalogIntelligenceController.php:150
 * @route '/catalog/intelligence/runs/{run}/approve-high-confidence'
 */
    const approveHighConfidenceForm = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveHighConfidence.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogIntelligenceController::approveHighConfidence
 * @see app/Http/Controllers/CatalogIntelligenceController.php:150
 * @route '/catalog/intelligence/runs/{run}/approve-high-confidence'
 */
        approveHighConfidenceForm.post = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveHighConfidence.url(args, options),
            method: 'post',
        })
    
    approveHighConfidence.form = approveHighConfidenceForm
/**
* @see \App\Http\Controllers\CatalogIntelligenceController::execute
 * @see app/Http/Controllers/CatalogIntelligenceController.php:164
 * @route '/catalog/intelligence/runs/{run}/execute'
 */
export const execute = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: execute.url(args, options),
    method: 'post',
})

execute.definition = {
    methods: ["post"],
    url: '/catalog/intelligence/runs/{run}/execute',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::execute
 * @see app/Http/Controllers/CatalogIntelligenceController.php:164
 * @route '/catalog/intelligence/runs/{run}/execute'
 */
execute.url = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { run: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { run: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    run: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        run: typeof args.run === 'object'
                ? args.run.id
                : args.run,
                }

    return execute.definition.url
            .replace('{run}', parsedArgs.run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::execute
 * @see app/Http/Controllers/CatalogIntelligenceController.php:164
 * @route '/catalog/intelligence/runs/{run}/execute'
 */
execute.post = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: execute.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CatalogIntelligenceController::execute
 * @see app/Http/Controllers/CatalogIntelligenceController.php:164
 * @route '/catalog/intelligence/runs/{run}/execute'
 */
    const executeForm = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: execute.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogIntelligenceController::execute
 * @see app/Http/Controllers/CatalogIntelligenceController.php:164
 * @route '/catalog/intelligence/runs/{run}/execute'
 */
        executeForm.post = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: execute.url(args, options),
            method: 'post',
        })
    
    execute.form = executeForm
/**
* @see \App\Http\Controllers\CatalogIntelligenceController::rollback
 * @see app/Http/Controllers/CatalogIntelligenceController.php:190
 * @route '/catalog/intelligence/runs/{run}/rollback'
 */
export const rollback = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rollback.url(args, options),
    method: 'post',
})

rollback.definition = {
    methods: ["post"],
    url: '/catalog/intelligence/runs/{run}/rollback',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::rollback
 * @see app/Http/Controllers/CatalogIntelligenceController.php:190
 * @route '/catalog/intelligence/runs/{run}/rollback'
 */
rollback.url = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { run: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { run: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    run: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        run: typeof args.run === 'object'
                ? args.run.id
                : args.run,
                }

    return rollback.definition.url
            .replace('{run}', parsedArgs.run.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::rollback
 * @see app/Http/Controllers/CatalogIntelligenceController.php:190
 * @route '/catalog/intelligence/runs/{run}/rollback'
 */
rollback.post = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rollback.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CatalogIntelligenceController::rollback
 * @see app/Http/Controllers/CatalogIntelligenceController.php:190
 * @route '/catalog/intelligence/runs/{run}/rollback'
 */
    const rollbackForm = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rollback.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogIntelligenceController::rollback
 * @see app/Http/Controllers/CatalogIntelligenceController.php:190
 * @route '/catalog/intelligence/runs/{run}/rollback'
 */
        rollbackForm.post = (args: { run: number | { id: number } } | [run: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rollback.url(args, options),
            method: 'post',
        })
    
    rollback.form = rollbackForm
const intelligence = {
    index: Object.assign(index, index),
generate: Object.assign(generate, generate),
candidates: Object.assign(candidates, candidates),
approveHighConfidence: Object.assign(approveHighConfidence, approveHighConfidence),
execute: Object.assign(execute, execute),
rollback: Object.assign(rollback, rollback),
}

export default intelligence