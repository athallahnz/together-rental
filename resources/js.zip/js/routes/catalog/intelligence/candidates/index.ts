import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CatalogIntelligenceController::review
 * @see app/Http/Controllers/CatalogIntelligenceController.php:125
 * @route '/catalog/intelligence/candidates/{candidate}'
 */
export const review = (args: { candidate: number | { id: number } } | [candidate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: review.url(args, options),
    method: 'patch',
})

review.definition = {
    methods: ["patch"],
    url: '/catalog/intelligence/candidates/{candidate}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::review
 * @see app/Http/Controllers/CatalogIntelligenceController.php:125
 * @route '/catalog/intelligence/candidates/{candidate}'
 */
review.url = (args: { candidate: number | { id: number } } | [candidate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { candidate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { candidate: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    candidate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        candidate: typeof args.candidate === 'object'
                ? args.candidate.id
                : args.candidate,
                }

    return review.definition.url
            .replace('{candidate}', parsedArgs.candidate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogIntelligenceController::review
 * @see app/Http/Controllers/CatalogIntelligenceController.php:125
 * @route '/catalog/intelligence/candidates/{candidate}'
 */
review.patch = (args: { candidate: number | { id: number } } | [candidate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: review.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CatalogIntelligenceController::review
 * @see app/Http/Controllers/CatalogIntelligenceController.php:125
 * @route '/catalog/intelligence/candidates/{candidate}'
 */
    const reviewForm = (args: { candidate: number | { id: number } } | [candidate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: review.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogIntelligenceController::review
 * @see app/Http/Controllers/CatalogIntelligenceController.php:125
 * @route '/catalog/intelligence/candidates/{candidate}'
 */
        reviewForm.patch = (args: { candidate: number | { id: number } } | [candidate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: review.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    review.form = reviewForm
const candidates = {
    review: Object.assign(review, review),
}

export default candidates