import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import products from './products'
import packages from './packages'
import categories from './categories'
import brands from './brands'
/**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/catalog/public-content',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const publicContent = {
    index: Object.assign(index, index),
products: Object.assign(products, products),
packages: Object.assign(packages, packages),
categories: Object.assign(categories, categories),
brands: Object.assign(brands, brands),
}

export default publicContent