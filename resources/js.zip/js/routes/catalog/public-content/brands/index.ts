import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
export const update = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/catalog/public-content/brands/{catalogBrand}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
update.url = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { catalogBrand: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { catalogBrand: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    catalogBrand: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        catalogBrand: typeof args.catalogBrand === 'object'
                ? args.catalogBrand.id
                : args.catalogBrand,
                }

    return update.definition.url
            .replace('{catalogBrand}', parsedArgs.catalogBrand.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
update.put = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
    const updateForm = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
        updateForm.put = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const brands = {
    update: Object.assign(update, update),
}

export default brands