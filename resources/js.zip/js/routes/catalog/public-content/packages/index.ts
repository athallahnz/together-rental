import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
export const update = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/catalog/public-content/packages/{rentalPackage}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
update.url = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rentalPackage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rentalPackage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rentalPackage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rentalPackage: typeof args.rentalPackage === 'object'
                ? args.rentalPackage.id
                : args.rentalPackage,
                }

    return update.definition.url
            .replace('{rentalPackage}', parsedArgs.rentalPackage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
update.put = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
    const updateForm = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogContentController::update
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
        updateForm.put = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const packages = {
    update: Object.assign(update, update),
}

export default packages