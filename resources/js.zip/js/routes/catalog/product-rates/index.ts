import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ProductRateController::store
 * @see app/Http/Controllers/ProductRateController.php:16
 * @route '/catalog/products/{product}/rates'
 */
export const store = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/catalog/products/{product}/rates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ProductRateController::store
 * @see app/Http/Controllers/ProductRateController.php:16
 * @route '/catalog/products/{product}/rates'
 */
store.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return store.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductRateController::store
 * @see app/Http/Controllers/ProductRateController.php:16
 * @route '/catalog/products/{product}/rates'
 */
store.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ProductRateController::store
 * @see app/Http/Controllers/ProductRateController.php:16
 * @route '/catalog/products/{product}/rates'
 */
    const storeForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProductRateController::store
 * @see app/Http/Controllers/ProductRateController.php:16
 * @route '/catalog/products/{product}/rates'
 */
        storeForm.post = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ProductRateController::update
 * @see app/Http/Controllers/ProductRateController.php:37
 * @route '/catalog/product-rates/{productRate}'
 */
export const update = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/catalog/product-rates/{productRate}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ProductRateController::update
 * @see app/Http/Controllers/ProductRateController.php:37
 * @route '/catalog/product-rates/{productRate}'
 */
update.url = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productRate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { productRate: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    productRate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        productRate: typeof args.productRate === 'object'
                ? args.productRate.id
                : args.productRate,
                }

    return update.definition.url
            .replace('{productRate}', parsedArgs.productRate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductRateController::update
 * @see app/Http/Controllers/ProductRateController.php:37
 * @route '/catalog/product-rates/{productRate}'
 */
update.put = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ProductRateController::update
 * @see app/Http/Controllers/ProductRateController.php:37
 * @route '/catalog/product-rates/{productRate}'
 */
    const updateForm = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProductRateController::update
 * @see app/Http/Controllers/ProductRateController.php:37
 * @route '/catalog/product-rates/{productRate}'
 */
        updateForm.put = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ProductRateController::destroy
 * @see app/Http/Controllers/ProductRateController.php:59
 * @route '/catalog/product-rates/{productRate}'
 */
export const destroy = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/catalog/product-rates/{productRate}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ProductRateController::destroy
 * @see app/Http/Controllers/ProductRateController.php:59
 * @route '/catalog/product-rates/{productRate}'
 */
destroy.url = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productRate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { productRate: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    productRate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        productRate: typeof args.productRate === 'object'
                ? args.productRate.id
                : args.productRate,
                }

    return destroy.definition.url
            .replace('{productRate}', parsedArgs.productRate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ProductRateController::destroy
 * @see app/Http/Controllers/ProductRateController.php:59
 * @route '/catalog/product-rates/{productRate}'
 */
destroy.delete = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ProductRateController::destroy
 * @see app/Http/Controllers/ProductRateController.php:59
 * @route '/catalog/product-rates/{productRate}'
 */
    const destroyForm = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ProductRateController::destroy
 * @see app/Http/Controllers/ProductRateController.php:59
 * @route '/catalog/product-rates/{productRate}'
 */
        destroyForm.delete = (args: { productRate: number | { id: number } } | [productRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const productRates = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default productRates