import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerAddressController::update
 * @see app/Http/Controllers/CustomerAddressController.php:49
 * @route '/customer-addresses/{customerAddress}'
 */
export const update = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/customer-addresses/{customerAddress}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CustomerAddressController::update
 * @see app/Http/Controllers/CustomerAddressController.php:49
 * @route '/customer-addresses/{customerAddress}'
 */
update.url = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customerAddress: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customerAddress: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customerAddress: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customerAddress: typeof args.customerAddress === 'object'
                ? args.customerAddress.id
                : args.customerAddress,
                }

    return update.definition.url
            .replace('{customerAddress}', parsedArgs.customerAddress.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerAddressController::update
 * @see app/Http/Controllers/CustomerAddressController.php:49
 * @route '/customer-addresses/{customerAddress}'
 */
update.put = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CustomerAddressController::update
 * @see app/Http/Controllers/CustomerAddressController.php:49
 * @route '/customer-addresses/{customerAddress}'
 */
    const updateForm = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CustomerAddressController::update
 * @see app/Http/Controllers/CustomerAddressController.php:49
 * @route '/customer-addresses/{customerAddress}'
 */
        updateForm.put = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CustomerAddressController::destroy
 * @see app/Http/Controllers/CustomerAddressController.php:93
 * @route '/customer-addresses/{customerAddress}'
 */
export const destroy = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/customer-addresses/{customerAddress}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CustomerAddressController::destroy
 * @see app/Http/Controllers/CustomerAddressController.php:93
 * @route '/customer-addresses/{customerAddress}'
 */
destroy.url = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customerAddress: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customerAddress: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customerAddress: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customerAddress: typeof args.customerAddress === 'object'
                ? args.customerAddress.id
                : args.customerAddress,
                }

    return destroy.definition.url
            .replace('{customerAddress}', parsedArgs.customerAddress.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerAddressController::destroy
 * @see app/Http/Controllers/CustomerAddressController.php:93
 * @route '/customer-addresses/{customerAddress}'
 */
destroy.delete = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CustomerAddressController::destroy
 * @see app/Http/Controllers/CustomerAddressController.php:93
 * @route '/customer-addresses/{customerAddress}'
 */
    const destroyForm = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CustomerAddressController::destroy
 * @see app/Http/Controllers/CustomerAddressController.php:93
 * @route '/customer-addresses/{customerAddress}'
 */
        destroyForm.delete = (args: { customerAddress: number | { id: number } } | [customerAddress: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const customerAddresses = {
    update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default customerAddresses