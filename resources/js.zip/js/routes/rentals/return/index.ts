import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\RentalController::create
 * @see app/Http/Controllers/RentalController.php:185
 * @route '/rentals/{rental}/return'
 */
export const create = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/rentals/{rental}/return',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RentalController::create
 * @see app/Http/Controllers/RentalController.php:185
 * @route '/rentals/{rental}/return'
 */
create.url = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rental: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rental: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rental: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rental: typeof args.rental === 'object'
                ? args.rental.id
                : args.rental,
                }

    return create.definition.url
            .replace('{rental}', parsedArgs.rental.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::create
 * @see app/Http/Controllers/RentalController.php:185
 * @route '/rentals/{rental}/return'
 */
create.get = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RentalController::create
 * @see app/Http/Controllers/RentalController.php:185
 * @route '/rentals/{rental}/return'
 */
create.head = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RentalController::create
 * @see app/Http/Controllers/RentalController.php:185
 * @route '/rentals/{rental}/return'
 */
    const createForm = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RentalController::create
 * @see app/Http/Controllers/RentalController.php:185
 * @route '/rentals/{rental}/return'
 */
        createForm.get = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RentalController::create
 * @see app/Http/Controllers/RentalController.php:185
 * @route '/rentals/{rental}/return'
 */
        createForm.head = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:250
 * @route '/rentals/{rental}/return'
 */
export const store = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/rentals/{rental}/return',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:250
 * @route '/rentals/{rental}/return'
 */
store.url = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rental: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rental: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rental: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rental: typeof args.rental === 'object'
                ? args.rental.id
                : args.rental,
                }

    return store.definition.url
            .replace('{rental}', parsedArgs.rental.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:250
 * @route '/rentals/{rental}/return'
 */
store.post = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:250
 * @route '/rentals/{rental}/return'
 */
    const storeForm = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalController::store
 * @see app/Http/Controllers/RentalController.php:250
 * @route '/rentals/{rental}/return'
 */
        storeForm.post = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const returnMethod = {
    create: Object.assign(create, create),
store: Object.assign(store, store),
}

export default returnMethod