import assetAnalytics from './asset-analytics'
const reports = {
    assetAnalytics: Object.assign(assetAnalytics, assetAnalytics),
}

export default reports