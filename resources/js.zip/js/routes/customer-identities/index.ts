import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\CustomerIdentityController::update
 * @see app/Http/Controllers/CustomerIdentityController.php:56
 * @route '/customer-identities/{customerIdentity}'
 */
export const update = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/customer-identities/{customerIdentity}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CustomerIdentityController::update
 * @see app/Http/Controllers/CustomerIdentityController.php:56
 * @route '/customer-identities/{customerIdentity}'
 */
update.url = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customerIdentity: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customerIdentity: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customerIdentity: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customerIdentity: typeof args.customerIdentity === 'object'
                ? args.customerIdentity.id
                : args.customerIdentity,
                }

    return update.definition.url
            .replace('{customerIdentity}', parsedArgs.customerIdentity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIdentityController::update
 * @see app/Http/Controllers/CustomerIdentityController.php:56
 * @route '/customer-identities/{customerIdentity}'
 */
update.put = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CustomerIdentityController::update
 * @see app/Http/Controllers/CustomerIdentityController.php:56
 * @route '/customer-identities/{customerIdentity}'
 */
    const updateForm = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CustomerIdentityController::update
 * @see app/Http/Controllers/CustomerIdentityController.php:56
 * @route '/customer-identities/{customerIdentity}'
 */
        updateForm.put = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CustomerIdentityController::verify
 * @see app/Http/Controllers/CustomerIdentityController.php:115
 * @route '/customer-identities/{customerIdentity}/verify'
 */
export const verify = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: verify.url(args, options),
    method: 'patch',
})

verify.definition = {
    methods: ["patch"],
    url: '/customer-identities/{customerIdentity}/verify',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CustomerIdentityController::verify
 * @see app/Http/Controllers/CustomerIdentityController.php:115
 * @route '/customer-identities/{customerIdentity}/verify'
 */
verify.url = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customerIdentity: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customerIdentity: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customerIdentity: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customerIdentity: typeof args.customerIdentity === 'object'
                ? args.customerIdentity.id
                : args.customerIdentity,
                }

    return verify.definition.url
            .replace('{customerIdentity}', parsedArgs.customerIdentity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIdentityController::verify
 * @see app/Http/Controllers/CustomerIdentityController.php:115
 * @route '/customer-identities/{customerIdentity}/verify'
 */
verify.patch = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: verify.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CustomerIdentityController::verify
 * @see app/Http/Controllers/CustomerIdentityController.php:115
 * @route '/customer-identities/{customerIdentity}/verify'
 */
    const verifyForm = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verify.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CustomerIdentityController::verify
 * @see app/Http/Controllers/CustomerIdentityController.php:115
 * @route '/customer-identities/{customerIdentity}/verify'
 */
        verifyForm.patch = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verify.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    verify.form = verifyForm
/**
* @see \App\Http\Controllers\CustomerIdentityController::destroy
 * @see app/Http/Controllers/CustomerIdentityController.php:158
 * @route '/customer-identities/{customerIdentity}'
 */
export const destroy = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/customer-identities/{customerIdentity}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CustomerIdentityController::destroy
 * @see app/Http/Controllers/CustomerIdentityController.php:158
 * @route '/customer-identities/{customerIdentity}'
 */
destroy.url = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { customerIdentity: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { customerIdentity: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    customerIdentity: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        customerIdentity: typeof args.customerIdentity === 'object'
                ? args.customerIdentity.id
                : args.customerIdentity,
                }

    return destroy.definition.url
            .replace('{customerIdentity}', parsedArgs.customerIdentity.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CustomerIdentityController::destroy
 * @see app/Http/Controllers/CustomerIdentityController.php:158
 * @route '/customer-identities/{customerIdentity}'
 */
destroy.delete = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CustomerIdentityController::destroy
 * @see app/Http/Controllers/CustomerIdentityController.php:158
 * @route '/customer-identities/{customerIdentity}'
 */
    const destroyForm = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CustomerIdentityController::destroy
 * @see app/Http/Controllers/CustomerIdentityController.php:158
 * @route '/customer-identities/{customerIdentity}'
 */
        destroyForm.delete = (args: { customerIdentity: number | { id: number } } | [customerIdentity: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const customerIdentities = {
    update: Object.assign(update, update),
verify: Object.assign(verify, verify),
destroy: Object.assign(destroy, destroy),
}

export default customerIdentities