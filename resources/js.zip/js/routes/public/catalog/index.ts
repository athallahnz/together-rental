import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
import products from './products'
import packages from './packages'
/**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/rental',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
export const availability = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})

availability.definition = {
    methods: ["get","head"],
    url: '/rental/availability',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
availability.url = (options?: RouteQueryOptions) => {
    return availability.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
availability.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
availability.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availability.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
    const availabilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: availability.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
        availabilityForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
        availabilityForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    availability.form = availabilityForm
const catalog = {
    index: Object.assign(index, index),
availability: Object.assign(availability, availability),
products: Object.assign(products, products),
packages: Object.assign(packages, packages),
}

export default catalog