import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CatalogController::index
 * @see app/Http/Controllers/CatalogController.php:22
 * @route '/catalog'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/catalog',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CatalogController::index
 * @see app/Http/Controllers/CatalogController.php:22
 * @route '/catalog'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogController::index
 * @see app/Http/Controllers/CatalogController.php:22
 * @route '/catalog'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CatalogController::index
 * @see app/Http/Controllers/CatalogController.php:22
 * @route '/catalog'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CatalogController::index
 * @see app/Http/Controllers/CatalogController.php:22
 * @route '/catalog'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CatalogController::index
 * @see app/Http/Controllers/CatalogController.php:22
 * @route '/catalog'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CatalogController::index
 * @see app/Http/Controllers/CatalogController.php:22
 * @route '/catalog'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CatalogController::product
 * @see app/Http/Controllers/CatalogController.php:216
 * @route '/catalog/products/{product}'
 */
export const product = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product.url(args, options),
    method: 'get',
})

product.definition = {
    methods: ["get","head"],
    url: '/catalog/products/{product}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CatalogController::product
 * @see app/Http/Controllers/CatalogController.php:216
 * @route '/catalog/products/{product}'
 */
product.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return product.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogController::product
 * @see app/Http/Controllers/CatalogController.php:216
 * @route '/catalog/products/{product}'
 */
product.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CatalogController::product
 * @see app/Http/Controllers/CatalogController.php:216
 * @route '/catalog/products/{product}'
 */
product.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: product.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CatalogController::product
 * @see app/Http/Controllers/CatalogController.php:216
 * @route '/catalog/products/{product}'
 */
    const productForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: product.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CatalogController::product
 * @see app/Http/Controllers/CatalogController.php:216
 * @route '/catalog/products/{product}'
 */
        productForm.get = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: product.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CatalogController::product
 * @see app/Http/Controllers/CatalogController.php:216
 * @route '/catalog/products/{product}'
 */
        productForm.head = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: product.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    product.form = productForm
/**
* @see \App\Http\Controllers\CatalogController::packageMethod
 * @see app/Http/Controllers/CatalogController.php:267
 * @route '/catalog/packages/{rentalPackage}'
 */
export const packageMethod = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: packageMethod.url(args, options),
    method: 'get',
})

packageMethod.definition = {
    methods: ["get","head"],
    url: '/catalog/packages/{rentalPackage}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CatalogController::packageMethod
 * @see app/Http/Controllers/CatalogController.php:267
 * @route '/catalog/packages/{rentalPackage}'
 */
packageMethod.url = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rentalPackage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rentalPackage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rentalPackage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rentalPackage: typeof args.rentalPackage === 'object'
                ? args.rentalPackage.id
                : args.rentalPackage,
                }

    return packageMethod.definition.url
            .replace('{rentalPackage}', parsedArgs.rentalPackage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogController::packageMethod
 * @see app/Http/Controllers/CatalogController.php:267
 * @route '/catalog/packages/{rentalPackage}'
 */
packageMethod.get = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: packageMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CatalogController::packageMethod
 * @see app/Http/Controllers/CatalogController.php:267
 * @route '/catalog/packages/{rentalPackage}'
 */
packageMethod.head = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: packageMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CatalogController::packageMethod
 * @see app/Http/Controllers/CatalogController.php:267
 * @route '/catalog/packages/{rentalPackage}'
 */
    const packageMethodForm = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: packageMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CatalogController::packageMethod
 * @see app/Http/Controllers/CatalogController.php:267
 * @route '/catalog/packages/{rentalPackage}'
 */
        packageMethodForm.get = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: packageMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CatalogController::packageMethod
 * @see app/Http/Controllers/CatalogController.php:267
 * @route '/catalog/packages/{rentalPackage}'
 */
        packageMethodForm.head = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: packageMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    packageMethod.form = packageMethodForm
const CatalogController = { index, product, packageMethod, package: packageMethod }

export default CatalogController