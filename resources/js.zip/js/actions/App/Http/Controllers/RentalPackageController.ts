import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RentalPackageController::store
 * @see app/Http/Controllers/RentalPackageController.php:17
 * @route '/catalog/packages'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/catalog/packages',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RentalPackageController::store
 * @see app/Http/Controllers/RentalPackageController.php:17
 * @route '/catalog/packages'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalPackageController::store
 * @see app/Http/Controllers/RentalPackageController.php:17
 * @route '/catalog/packages'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RentalPackageController::store
 * @see app/Http/Controllers/RentalPackageController.php:17
 * @route '/catalog/packages'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalPackageController::store
 * @see app/Http/Controllers/RentalPackageController.php:17
 * @route '/catalog/packages'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\RentalPackageController::update
 * @see app/Http/Controllers/RentalPackageController.php:40
 * @route '/catalog/packages/{rentalPackage}'
 */
export const update = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/catalog/packages/{rentalPackage}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\RentalPackageController::update
 * @see app/Http/Controllers/RentalPackageController.php:40
 * @route '/catalog/packages/{rentalPackage}'
 */
update.url = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rentalPackage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rentalPackage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rentalPackage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rentalPackage: typeof args.rentalPackage === 'object'
                ? args.rentalPackage.id
                : args.rentalPackage,
                }

    return update.definition.url
            .replace('{rentalPackage}', parsedArgs.rentalPackage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalPackageController::update
 * @see app/Http/Controllers/RentalPackageController.php:40
 * @route '/catalog/packages/{rentalPackage}'
 */
update.put = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\RentalPackageController::update
 * @see app/Http/Controllers/RentalPackageController.php:40
 * @route '/catalog/packages/{rentalPackage}'
 */
    const updateForm = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalPackageController::update
 * @see app/Http/Controllers/RentalPackageController.php:40
 * @route '/catalog/packages/{rentalPackage}'
 */
        updateForm.put = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\RentalPackageController::archive
 * @see app/Http/Controllers/RentalPackageController.php:73
 * @route '/catalog/packages/{rentalPackage}'
 */
export const archive = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: archive.url(args, options),
    method: 'delete',
})

archive.definition = {
    methods: ["delete"],
    url: '/catalog/packages/{rentalPackage}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\RentalPackageController::archive
 * @see app/Http/Controllers/RentalPackageController.php:73
 * @route '/catalog/packages/{rentalPackage}'
 */
archive.url = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rentalPackage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rentalPackage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rentalPackage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rentalPackage: typeof args.rentalPackage === 'object'
                ? args.rentalPackage.id
                : args.rentalPackage,
                }

    return archive.definition.url
            .replace('{rentalPackage}', parsedArgs.rentalPackage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalPackageController::archive
 * @see app/Http/Controllers/RentalPackageController.php:73
 * @route '/catalog/packages/{rentalPackage}'
 */
archive.delete = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: archive.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\RentalPackageController::archive
 * @see app/Http/Controllers/RentalPackageController.php:73
 * @route '/catalog/packages/{rentalPackage}'
 */
    const archiveForm = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalPackageController::archive
 * @see app/Http/Controllers/RentalPackageController.php:73
 * @route '/catalog/packages/{rentalPackage}'
 */
        archiveForm.delete = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
const RentalPackageController = { store, update, archive }

export default RentalPackageController