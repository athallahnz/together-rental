import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicCatalogController::home
 * @see app/Http/Controllers/PublicCatalogController.php:16
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogController::home
 * @see app/Http/Controllers/PublicCatalogController.php:16
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogController::home
 * @see app/Http/Controllers/PublicCatalogController.php:16
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogController::home
 * @see app/Http/Controllers/PublicCatalogController.php:16
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogController::home
 * @see app/Http/Controllers/PublicCatalogController.php:16
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogController::home
 * @see app/Http/Controllers/PublicCatalogController.php:16
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogController::home
 * @see app/Http/Controllers/PublicCatalogController.php:16
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/rental',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogController::index
 * @see app/Http/Controllers/PublicCatalogController.php:24
 * @route '/rental'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
export const availability = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})

availability.definition = {
    methods: ["get","head"],
    url: '/rental/availability',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
availability.url = (options?: RouteQueryOptions) => {
    return availability.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
availability.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: availability.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
availability.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: availability.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
    const availabilityForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: availability.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
        availabilityForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogController::availability
 * @see app/Http/Controllers/PublicCatalogController.php:62
 * @route '/rental/availability'
 */
        availabilityForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: availability.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    availability.form = availabilityForm
/**
* @see \App\Http\Controllers\PublicCatalogController::product
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
export const product = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product.url(args, options),
    method: 'get',
})

product.definition = {
    methods: ["get","head"],
    url: '/rental/products/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogController::product
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
product.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return product.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogController::product
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
product.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: product.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogController::product
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
product.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: product.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogController::product
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
    const productForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: product.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogController::product
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
        productForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: product.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogController::product
 * @see app/Http/Controllers/PublicCatalogController.php:34
 * @route '/rental/products/{slug}'
 */
        productForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: product.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    product.form = productForm
/**
* @see \App\Http\Controllers\PublicCatalogController::packageMethod
 * @see app/Http/Controllers/PublicCatalogController.php:48
 * @route '/rental/packages/{slug}'
 */
export const packageMethod = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: packageMethod.url(args, options),
    method: 'get',
})

packageMethod.definition = {
    methods: ["get","head"],
    url: '/rental/packages/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogController::packageMethod
 * @see app/Http/Controllers/PublicCatalogController.php:48
 * @route '/rental/packages/{slug}'
 */
packageMethod.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return packageMethod.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogController::packageMethod
 * @see app/Http/Controllers/PublicCatalogController.php:48
 * @route '/rental/packages/{slug}'
 */
packageMethod.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: packageMethod.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogController::packageMethod
 * @see app/Http/Controllers/PublicCatalogController.php:48
 * @route '/rental/packages/{slug}'
 */
packageMethod.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: packageMethod.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogController::packageMethod
 * @see app/Http/Controllers/PublicCatalogController.php:48
 * @route '/rental/packages/{slug}'
 */
    const packageMethodForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: packageMethod.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogController::packageMethod
 * @see app/Http/Controllers/PublicCatalogController.php:48
 * @route '/rental/packages/{slug}'
 */
        packageMethodForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: packageMethod.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogController::packageMethod
 * @see app/Http/Controllers/PublicCatalogController.php:48
 * @route '/rental/packages/{slug}'
 */
        packageMethodForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: packageMethod.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    packageMethod.form = packageMethodForm
const PublicCatalogController = { home, index, availability, product, packageMethod, package: packageMethod }

export default PublicCatalogController