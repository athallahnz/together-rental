import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/catalog/public-content',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicCatalogContentController::index
 * @see app/Http/Controllers/PublicCatalogContentController.php:26
 * @route '/catalog/public-content'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateProduct
 * @see app/Http/Controllers/PublicCatalogContentController.php:274
 * @route '/catalog/public-content/products/{product}'
 */
export const updateProduct = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProduct.url(args, options),
    method: 'put',
})

updateProduct.definition = {
    methods: ["put"],
    url: '/catalog/public-content/products/{product}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateProduct
 * @see app/Http/Controllers/PublicCatalogContentController.php:274
 * @route '/catalog/public-content/products/{product}'
 */
updateProduct.url = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { product: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { product: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    product: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        product: typeof args.product === 'object'
                ? args.product.id
                : args.product,
                }

    return updateProduct.definition.url
            .replace('{product}', parsedArgs.product.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateProduct
 * @see app/Http/Controllers/PublicCatalogContentController.php:274
 * @route '/catalog/public-content/products/{product}'
 */
updateProduct.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProduct.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\PublicCatalogContentController::updateProduct
 * @see app/Http/Controllers/PublicCatalogContentController.php:274
 * @route '/catalog/public-content/products/{product}'
 */
    const updateProductForm = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateProduct.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogContentController::updateProduct
 * @see app/Http/Controllers/PublicCatalogContentController.php:274
 * @route '/catalog/public-content/products/{product}'
 */
        updateProductForm.put = (args: { product: number | { id: number } } | [product: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateProduct.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateProduct.form = updateProductForm
/**
* @see \App\Http\Controllers\PublicCatalogContentController::updatePackage
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
export const updatePackage = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePackage.url(args, options),
    method: 'put',
})

updatePackage.definition = {
    methods: ["put"],
    url: '/catalog/public-content/packages/{rentalPackage}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PublicCatalogContentController::updatePackage
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
updatePackage.url = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rentalPackage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rentalPackage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rentalPackage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rentalPackage: typeof args.rentalPackage === 'object'
                ? args.rentalPackage.id
                : args.rentalPackage,
                }

    return updatePackage.definition.url
            .replace('{rentalPackage}', parsedArgs.rentalPackage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogContentController::updatePackage
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
updatePackage.put = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updatePackage.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\PublicCatalogContentController::updatePackage
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
    const updatePackageForm = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updatePackage.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogContentController::updatePackage
 * @see app/Http/Controllers/PublicCatalogContentController.php:372
 * @route '/catalog/public-content/packages/{rentalPackage}'
 */
        updatePackageForm.put = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updatePackage.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updatePackage.form = updatePackageForm
/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateCategory
 * @see app/Http/Controllers/PublicCatalogContentController.php:437
 * @route '/catalog/public-content/categories/{productCategory}'
 */
export const updateCategory = (args: { productCategory: number | { id: number } } | [productCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCategory.url(args, options),
    method: 'put',
})

updateCategory.definition = {
    methods: ["put"],
    url: '/catalog/public-content/categories/{productCategory}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateCategory
 * @see app/Http/Controllers/PublicCatalogContentController.php:437
 * @route '/catalog/public-content/categories/{productCategory}'
 */
updateCategory.url = (args: { productCategory: number | { id: number } } | [productCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { productCategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { productCategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    productCategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        productCategory: typeof args.productCategory === 'object'
                ? args.productCategory.id
                : args.productCategory,
                }

    return updateCategory.definition.url
            .replace('{productCategory}', parsedArgs.productCategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateCategory
 * @see app/Http/Controllers/PublicCatalogContentController.php:437
 * @route '/catalog/public-content/categories/{productCategory}'
 */
updateCategory.put = (args: { productCategory: number | { id: number } } | [productCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCategory.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\PublicCatalogContentController::updateCategory
 * @see app/Http/Controllers/PublicCatalogContentController.php:437
 * @route '/catalog/public-content/categories/{productCategory}'
 */
    const updateCategoryForm = (args: { productCategory: number | { id: number } } | [productCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogContentController::updateCategory
 * @see app/Http/Controllers/PublicCatalogContentController.php:437
 * @route '/catalog/public-content/categories/{productCategory}'
 */
        updateCategoryForm.put = (args: { productCategory: number | { id: number } } | [productCategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateCategory.form = updateCategoryForm
/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateBrand
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
export const updateBrand = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBrand.url(args, options),
    method: 'put',
})

updateBrand.definition = {
    methods: ["put"],
    url: '/catalog/public-content/brands/{catalogBrand}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateBrand
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
updateBrand.url = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { catalogBrand: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { catalogBrand: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    catalogBrand: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        catalogBrand: typeof args.catalogBrand === 'object'
                ? args.catalogBrand.id
                : args.catalogBrand,
                }

    return updateBrand.definition.url
            .replace('{catalogBrand}', parsedArgs.catalogBrand.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicCatalogContentController::updateBrand
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
updateBrand.put = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateBrand.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\PublicCatalogContentController::updateBrand
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
    const updateBrandForm = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateBrand.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PublicCatalogContentController::updateBrand
 * @see app/Http/Controllers/PublicCatalogContentController.php:497
 * @route '/catalog/public-content/brands/{catalogBrand}'
 */
        updateBrandForm.put = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateBrand.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateBrand.form = updateBrandForm
const PublicCatalogContentController = { index, updateProduct, updatePackage, updateCategory, updateBrand }

export default PublicCatalogContentController