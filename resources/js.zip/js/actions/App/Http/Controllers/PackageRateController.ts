import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PackageRateController::store
 * @see app/Http/Controllers/PackageRateController.php:16
 * @route '/catalog/packages/{rentalPackage}/rates'
 */
export const store = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/catalog/packages/{rentalPackage}/rates',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PackageRateController::store
 * @see app/Http/Controllers/PackageRateController.php:16
 * @route '/catalog/packages/{rentalPackage}/rates'
 */
store.url = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rentalPackage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rentalPackage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rentalPackage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rentalPackage: typeof args.rentalPackage === 'object'
                ? args.rentalPackage.id
                : args.rentalPackage,
                }

    return store.definition.url
            .replace('{rentalPackage}', parsedArgs.rentalPackage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackageRateController::store
 * @see app/Http/Controllers/PackageRateController.php:16
 * @route '/catalog/packages/{rentalPackage}/rates'
 */
store.post = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PackageRateController::store
 * @see app/Http/Controllers/PackageRateController.php:16
 * @route '/catalog/packages/{rentalPackage}/rates'
 */
    const storeForm = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PackageRateController::store
 * @see app/Http/Controllers/PackageRateController.php:16
 * @route '/catalog/packages/{rentalPackage}/rates'
 */
        storeForm.post = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\PackageRateController::update
 * @see app/Http/Controllers/PackageRateController.php:37
 * @route '/catalog/package-rates/{packageRate}'
 */
export const update = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/catalog/package-rates/{packageRate}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\PackageRateController::update
 * @see app/Http/Controllers/PackageRateController.php:37
 * @route '/catalog/package-rates/{packageRate}'
 */
update.url = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { packageRate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { packageRate: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    packageRate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        packageRate: typeof args.packageRate === 'object'
                ? args.packageRate.id
                : args.packageRate,
                }

    return update.definition.url
            .replace('{packageRate}', parsedArgs.packageRate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackageRateController::update
 * @see app/Http/Controllers/PackageRateController.php:37
 * @route '/catalog/package-rates/{packageRate}'
 */
update.put = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\PackageRateController::update
 * @see app/Http/Controllers/PackageRateController.php:37
 * @route '/catalog/package-rates/{packageRate}'
 */
    const updateForm = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PackageRateController::update
 * @see app/Http/Controllers/PackageRateController.php:37
 * @route '/catalog/package-rates/{packageRate}'
 */
        updateForm.put = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\PackageRateController::destroy
 * @see app/Http/Controllers/PackageRateController.php:59
 * @route '/catalog/package-rates/{packageRate}'
 */
export const destroy = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/catalog/package-rates/{packageRate}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PackageRateController::destroy
 * @see app/Http/Controllers/PackageRateController.php:59
 * @route '/catalog/package-rates/{packageRate}'
 */
destroy.url = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { packageRate: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { packageRate: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    packageRate: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        packageRate: typeof args.packageRate === 'object'
                ? args.packageRate.id
                : args.packageRate,
                }

    return destroy.definition.url
            .replace('{packageRate}', parsedArgs.packageRate.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackageRateController::destroy
 * @see app/Http/Controllers/PackageRateController.php:59
 * @route '/catalog/package-rates/{packageRate}'
 */
destroy.delete = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PackageRateController::destroy
 * @see app/Http/Controllers/PackageRateController.php:59
 * @route '/catalog/package-rates/{packageRate}'
 */
    const destroyForm = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PackageRateController::destroy
 * @see app/Http/Controllers/PackageRateController.php:59
 * @route '/catalog/package-rates/{packageRate}'
 */
        destroyForm.delete = (args: { packageRate: number | { id: number } } | [packageRate: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const PackageRateController = { store, update, destroy }

export default PackageRateController