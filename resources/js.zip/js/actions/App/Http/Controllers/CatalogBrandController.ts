import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CatalogBrandController::updateVisual
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
export const updateVisual = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateVisual.url(args, options),
    method: 'post',
})

updateVisual.definition = {
    methods: ["post"],
    url: '/catalog/brands/{catalogBrand}/visual',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CatalogBrandController::updateVisual
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
updateVisual.url = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { catalogBrand: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { catalogBrand: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    catalogBrand: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        catalogBrand: typeof args.catalogBrand === 'object'
                ? args.catalogBrand.id
                : args.catalogBrand,
                }

    return updateVisual.definition.url
            .replace('{catalogBrand}', parsedArgs.catalogBrand.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogBrandController::updateVisual
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
updateVisual.post = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateVisual.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CatalogBrandController::updateVisual
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
    const updateVisualForm = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateVisual.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogBrandController::updateVisual
 * @see app/Http/Controllers/CatalogBrandController.php:14
 * @route '/catalog/brands/{catalogBrand}/visual'
 */
        updateVisualForm.post = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateVisual.url(args, options),
            method: 'post',
        })
    
    updateVisual.form = updateVisualForm
/**
* @see \App\Http\Controllers\CatalogBrandController::destroyLogo
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
export const destroyLogo = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyLogo.url(args, options),
    method: 'delete',
})

destroyLogo.definition = {
    methods: ["delete"],
    url: '/catalog/brands/{catalogBrand}/logo',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CatalogBrandController::destroyLogo
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
destroyLogo.url = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { catalogBrand: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { catalogBrand: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    catalogBrand: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        catalogBrand: typeof args.catalogBrand === 'object'
                ? args.catalogBrand.id
                : args.catalogBrand,
                }

    return destroyLogo.definition.url
            .replace('{catalogBrand}', parsedArgs.catalogBrand.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CatalogBrandController::destroyLogo
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
destroyLogo.delete = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyLogo.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CatalogBrandController::destroyLogo
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
    const destroyLogoForm = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyLogo.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CatalogBrandController::destroyLogo
 * @see app/Http/Controllers/CatalogBrandController.php:69
 * @route '/catalog/brands/{catalogBrand}/logo'
 */
        destroyLogoForm.delete = (args: { catalogBrand: number | { id: number } } | [catalogBrand: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyLogo.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyLogo.form = destroyLogoForm
const CatalogBrandController = { updateVisual, destroyLogo }

export default CatalogBrandController