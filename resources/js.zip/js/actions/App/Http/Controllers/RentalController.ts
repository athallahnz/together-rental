import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:27
 * @route '/rentals'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/rentals',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:27
 * @route '/rentals'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:27
 * @route '/rentals'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:27
 * @route '/rentals'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:27
 * @route '/rentals'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:27
 * @route '/rentals'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RentalController::index
 * @see app/Http/Controllers/RentalController.php:27
 * @route '/rentals'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\RentalController::createDirect
 * @see app/Http/Controllers/RentalController.php:90
 * @route '/rentals/direct/create'
 */
export const createDirect = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createDirect.url(options),
    method: 'get',
})

createDirect.definition = {
    methods: ["get","head"],
    url: '/rentals/direct/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RentalController::createDirect
 * @see app/Http/Controllers/RentalController.php:90
 * @route '/rentals/direct/create'
 */
createDirect.url = (options?: RouteQueryOptions) => {
    return createDirect.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::createDirect
 * @see app/Http/Controllers/RentalController.php:90
 * @route '/rentals/direct/create'
 */
createDirect.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createDirect.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RentalController::createDirect
 * @see app/Http/Controllers/RentalController.php:90
 * @route '/rentals/direct/create'
 */
createDirect.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createDirect.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RentalController::createDirect
 * @see app/Http/Controllers/RentalController.php:90
 * @route '/rentals/direct/create'
 */
    const createDirectForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: createDirect.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RentalController::createDirect
 * @see app/Http/Controllers/RentalController.php:90
 * @route '/rentals/direct/create'
 */
        createDirectForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createDirect.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RentalController::createDirect
 * @see app/Http/Controllers/RentalController.php:90
 * @route '/rentals/direct/create'
 */
        createDirectForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createDirect.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    createDirect.form = createDirectForm
/**
* @see \App\Http\Controllers\RentalController::storeDirect
 * @see app/Http/Controllers/RentalController.php:101
 * @route '/rentals/direct'
 */
export const storeDirect = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeDirect.url(options),
    method: 'post',
})

storeDirect.definition = {
    methods: ["post"],
    url: '/rentals/direct',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RentalController::storeDirect
 * @see app/Http/Controllers/RentalController.php:101
 * @route '/rentals/direct'
 */
storeDirect.url = (options?: RouteQueryOptions) => {
    return storeDirect.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::storeDirect
 * @see app/Http/Controllers/RentalController.php:101
 * @route '/rentals/direct'
 */
storeDirect.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeDirect.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RentalController::storeDirect
 * @see app/Http/Controllers/RentalController.php:101
 * @route '/rentals/direct'
 */
    const storeDirectForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeDirect.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalController::storeDirect
 * @see app/Http/Controllers/RentalController.php:101
 * @route '/rentals/direct'
 */
        storeDirectForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeDirect.url(options),
            method: 'post',
        })
    
    storeDirect.form = storeDirectForm
/**
* @see \App\Http\Controllers\RentalController::createCheckout
 * @see app/Http/Controllers/RentalController.php:122
 * @route '/rentals/checkout/{booking}'
 */
export const createCheckout = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCheckout.url(args, options),
    method: 'get',
})

createCheckout.definition = {
    methods: ["get","head"],
    url: '/rentals/checkout/{booking}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RentalController::createCheckout
 * @see app/Http/Controllers/RentalController.php:122
 * @route '/rentals/checkout/{booking}'
 */
createCheckout.url = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { booking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { booking: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    booking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        booking: typeof args.booking === 'object'
                ? args.booking.id
                : args.booking,
                }

    return createCheckout.definition.url
            .replace('{booking}', parsedArgs.booking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::createCheckout
 * @see app/Http/Controllers/RentalController.php:122
 * @route '/rentals/checkout/{booking}'
 */
createCheckout.get = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCheckout.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RentalController::createCheckout
 * @see app/Http/Controllers/RentalController.php:122
 * @route '/rentals/checkout/{booking}'
 */
createCheckout.head = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCheckout.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RentalController::createCheckout
 * @see app/Http/Controllers/RentalController.php:122
 * @route '/rentals/checkout/{booking}'
 */
    const createCheckoutForm = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: createCheckout.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RentalController::createCheckout
 * @see app/Http/Controllers/RentalController.php:122
 * @route '/rentals/checkout/{booking}'
 */
        createCheckoutForm.get = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createCheckout.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RentalController::createCheckout
 * @see app/Http/Controllers/RentalController.php:122
 * @route '/rentals/checkout/{booking}'
 */
        createCheckoutForm.head = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createCheckout.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    createCheckout.form = createCheckoutForm
/**
* @see \App\Http\Controllers\RentalController::storeCheckout
 * @see app/Http/Controllers/RentalController.php:140
 * @route '/rentals/checkout/{booking}'
 */
export const storeCheckout = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCheckout.url(args, options),
    method: 'post',
})

storeCheckout.definition = {
    methods: ["post"],
    url: '/rentals/checkout/{booking}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RentalController::storeCheckout
 * @see app/Http/Controllers/RentalController.php:140
 * @route '/rentals/checkout/{booking}'
 */
storeCheckout.url = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { booking: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { booking: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    booking: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        booking: typeof args.booking === 'object'
                ? args.booking.id
                : args.booking,
                }

    return storeCheckout.definition.url
            .replace('{booking}', parsedArgs.booking.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::storeCheckout
 * @see app/Http/Controllers/RentalController.php:140
 * @route '/rentals/checkout/{booking}'
 */
storeCheckout.post = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCheckout.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RentalController::storeCheckout
 * @see app/Http/Controllers/RentalController.php:140
 * @route '/rentals/checkout/{booking}'
 */
    const storeCheckoutForm = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeCheckout.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RentalController::storeCheckout
 * @see app/Http/Controllers/RentalController.php:140
 * @route '/rentals/checkout/{booking}'
 */
        storeCheckoutForm.post = (args: { booking: number | { id: number } } | [booking: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeCheckout.url(args, options),
            method: 'post',
        })
    
    storeCheckout.form = storeCheckoutForm
/**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:163
 * @route '/rentals/{rental}'
 */
export const show = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/rentals/{rental}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:163
 * @route '/rentals/{rental}'
 */
show.url = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rental: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rental: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rental: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rental: typeof args.rental === 'object'
                ? args.rental.id
                : args.rental,
                }

    return show.definition.url
            .replace('{rental}', parsedArgs.rental.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:163
 * @route '/rentals/{rental}'
 */
show.get = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:163
 * @route '/rentals/{rental}'
 */
show.head = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:163
 * @route '/rentals/{rental}'
 */
    const showForm = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:163
 * @route '/rentals/{rental}'
 */
        showForm.get = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RentalController::show
 * @see app/Http/Controllers/RentalController.php:163
 * @route '/rentals/{rental}'
 */
        showForm.head = (args: { rental: number | { id: number } } | [rental: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const RentalController = { index, createDirect, storeDirect, createCheckout, storeCheckout, show }

export default RentalController