import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\LegacyImportController::index
 * @see app/Http/Controllers/LegacyImportController.php:23
 * @route '/legacy-imports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/legacy-imports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LegacyImportController::index
 * @see app/Http/Controllers/LegacyImportController.php:23
 * @route '/legacy-imports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LegacyImportController::index
 * @see app/Http/Controllers/LegacyImportController.php:23
 * @route '/legacy-imports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LegacyImportController::index
 * @see app/Http/Controllers/LegacyImportController.php:23
 * @route '/legacy-imports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LegacyImportController::index
 * @see app/Http/Controllers/LegacyImportController.php:23
 * @route '/legacy-imports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LegacyImportController::index
 * @see app/Http/Controllers/LegacyImportController.php:23
 * @route '/legacy-imports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LegacyImportController::index
 * @see app/Http/Controllers/LegacyImportController.php:23
 * @route '/legacy-imports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\LegacyImportController::store
 * @see app/Http/Controllers/LegacyImportController.php:44
 * @route '/legacy-imports'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/legacy-imports',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LegacyImportController::store
 * @see app/Http/Controllers/LegacyImportController.php:44
 * @route '/legacy-imports'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\LegacyImportController::store
 * @see app/Http/Controllers/LegacyImportController.php:44
 * @route '/legacy-imports'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LegacyImportController::store
 * @see app/Http/Controllers/LegacyImportController.php:44
 * @route '/legacy-imports'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LegacyImportController::store
 * @see app/Http/Controllers/LegacyImportController.php:44
 * @route '/legacy-imports'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\LegacyImportController::show
 * @see app/Http/Controllers/LegacyImportController.php:101
 * @route '/legacy-imports/{legacyImport}'
 */
export const show = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/legacy-imports/{legacyImport}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\LegacyImportController::show
 * @see app/Http/Controllers/LegacyImportController.php:101
 * @route '/legacy-imports/{legacyImport}'
 */
show.url = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { legacyImport: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { legacyImport: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    legacyImport: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        legacyImport: typeof args.legacyImport === 'object'
                ? args.legacyImport.id
                : args.legacyImport,
                }

    return show.definition.url
            .replace('{legacyImport}', parsedArgs.legacyImport.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LegacyImportController::show
 * @see app/Http/Controllers/LegacyImportController.php:101
 * @route '/legacy-imports/{legacyImport}'
 */
show.get = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\LegacyImportController::show
 * @see app/Http/Controllers/LegacyImportController.php:101
 * @route '/legacy-imports/{legacyImport}'
 */
show.head = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\LegacyImportController::show
 * @see app/Http/Controllers/LegacyImportController.php:101
 * @route '/legacy-imports/{legacyImport}'
 */
    const showForm = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\LegacyImportController::show
 * @see app/Http/Controllers/LegacyImportController.php:101
 * @route '/legacy-imports/{legacyImport}'
 */
        showForm.get = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\LegacyImportController::show
 * @see app/Http/Controllers/LegacyImportController.php:101
 * @route '/legacy-imports/{legacyImport}'
 */
        showForm.head = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\LegacyImportController::preview
 * @see app/Http/Controllers/LegacyImportController.php:151
 * @route '/legacy-imports/{legacyImport}/preview'
 */
export const preview = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preview.url(args, options),
    method: 'post',
})

preview.definition = {
    methods: ["post"],
    url: '/legacy-imports/{legacyImport}/preview',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LegacyImportController::preview
 * @see app/Http/Controllers/LegacyImportController.php:151
 * @route '/legacy-imports/{legacyImport}/preview'
 */
preview.url = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { legacyImport: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { legacyImport: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    legacyImport: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        legacyImport: typeof args.legacyImport === 'object'
                ? args.legacyImport.id
                : args.legacyImport,
                }

    return preview.definition.url
            .replace('{legacyImport}', parsedArgs.legacyImport.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LegacyImportController::preview
 * @see app/Http/Controllers/LegacyImportController.php:151
 * @route '/legacy-imports/{legacyImport}/preview'
 */
preview.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: preview.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LegacyImportController::preview
 * @see app/Http/Controllers/LegacyImportController.php:151
 * @route '/legacy-imports/{legacyImport}/preview'
 */
    const previewForm = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: preview.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LegacyImportController::preview
 * @see app/Http/Controllers/LegacyImportController.php:151
 * @route '/legacy-imports/{legacyImport}/preview'
 */
        previewForm.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: preview.url(args, options),
            method: 'post',
        })
    
    preview.form = previewForm
/**
* @see \App\Http\Controllers\LegacyImportController::validateBatch
 * @see app/Http/Controllers/LegacyImportController.php:167
 * @route '/legacy-imports/{legacyImport}/validate'
 */
export const validateBatch = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateBatch.url(args, options),
    method: 'post',
})

validateBatch.definition = {
    methods: ["post"],
    url: '/legacy-imports/{legacyImport}/validate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LegacyImportController::validateBatch
 * @see app/Http/Controllers/LegacyImportController.php:167
 * @route '/legacy-imports/{legacyImport}/validate'
 */
validateBatch.url = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { legacyImport: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { legacyImport: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    legacyImport: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        legacyImport: typeof args.legacyImport === 'object'
                ? args.legacyImport.id
                : args.legacyImport,
                }

    return validateBatch.definition.url
            .replace('{legacyImport}', parsedArgs.legacyImport.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LegacyImportController::validateBatch
 * @see app/Http/Controllers/LegacyImportController.php:167
 * @route '/legacy-imports/{legacyImport}/validate'
 */
validateBatch.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: validateBatch.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LegacyImportController::validateBatch
 * @see app/Http/Controllers/LegacyImportController.php:167
 * @route '/legacy-imports/{legacyImport}/validate'
 */
    const validateBatchForm = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: validateBatch.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LegacyImportController::validateBatch
 * @see app/Http/Controllers/LegacyImportController.php:167
 * @route '/legacy-imports/{legacyImport}/validate'
 */
        validateBatchForm.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: validateBatch.url(args, options),
            method: 'post',
        })
    
    validateBatch.form = validateBatchForm
/**
* @see \App\Http\Controllers\LegacyImportController::mapBranch
 * @see app/Http/Controllers/LegacyImportController.php:183
 * @route '/legacy-imports/{legacyImport}/map-branch'
 */
export const mapBranch = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mapBranch.url(args, options),
    method: 'post',
})

mapBranch.definition = {
    methods: ["post"],
    url: '/legacy-imports/{legacyImport}/map-branch',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LegacyImportController::mapBranch
 * @see app/Http/Controllers/LegacyImportController.php:183
 * @route '/legacy-imports/{legacyImport}/map-branch'
 */
mapBranch.url = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { legacyImport: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { legacyImport: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    legacyImport: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        legacyImport: typeof args.legacyImport === 'object'
                ? args.legacyImport.id
                : args.legacyImport,
                }

    return mapBranch.definition.url
            .replace('{legacyImport}', parsedArgs.legacyImport.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LegacyImportController::mapBranch
 * @see app/Http/Controllers/LegacyImportController.php:183
 * @route '/legacy-imports/{legacyImport}/map-branch'
 */
mapBranch.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: mapBranch.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LegacyImportController::mapBranch
 * @see app/Http/Controllers/LegacyImportController.php:183
 * @route '/legacy-imports/{legacyImport}/map-branch'
 */
    const mapBranchForm = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: mapBranch.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LegacyImportController::mapBranch
 * @see app/Http/Controllers/LegacyImportController.php:183
 * @route '/legacy-imports/{legacyImport}/map-branch'
 */
        mapBranchForm.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: mapBranch.url(args, options),
            method: 'post',
        })
    
    mapBranch.form = mapBranchForm
/**
* @see \App\Http\Controllers\LegacyImportController::execute
 * @see app/Http/Controllers/LegacyImportController.php:197
 * @route '/legacy-imports/{legacyImport}/execute'
 */
export const execute = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: execute.url(args, options),
    method: 'post',
})

execute.definition = {
    methods: ["post"],
    url: '/legacy-imports/{legacyImport}/execute',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LegacyImportController::execute
 * @see app/Http/Controllers/LegacyImportController.php:197
 * @route '/legacy-imports/{legacyImport}/execute'
 */
execute.url = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { legacyImport: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { legacyImport: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    legacyImport: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        legacyImport: typeof args.legacyImport === 'object'
                ? args.legacyImport.id
                : args.legacyImport,
                }

    return execute.definition.url
            .replace('{legacyImport}', parsedArgs.legacyImport.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LegacyImportController::execute
 * @see app/Http/Controllers/LegacyImportController.php:197
 * @route '/legacy-imports/{legacyImport}/execute'
 */
execute.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: execute.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LegacyImportController::execute
 * @see app/Http/Controllers/LegacyImportController.php:197
 * @route '/legacy-imports/{legacyImport}/execute'
 */
    const executeForm = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: execute.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LegacyImportController::execute
 * @see app/Http/Controllers/LegacyImportController.php:197
 * @route '/legacy-imports/{legacyImport}/execute'
 */
        executeForm.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: execute.url(args, options),
            method: 'post',
        })
    
    execute.form = executeForm
/**
* @see \App\Http\Controllers\LegacyImportController::verify
 * @see app/Http/Controllers/LegacyImportController.php:213
 * @route '/legacy-imports/{legacyImport}/verify'
 */
export const verify = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(args, options),
    method: 'post',
})

verify.definition = {
    methods: ["post"],
    url: '/legacy-imports/{legacyImport}/verify',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\LegacyImportController::verify
 * @see app/Http/Controllers/LegacyImportController.php:213
 * @route '/legacy-imports/{legacyImport}/verify'
 */
verify.url = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { legacyImport: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { legacyImport: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    legacyImport: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        legacyImport: typeof args.legacyImport === 'object'
                ? args.legacyImport.id
                : args.legacyImport,
                }

    return verify.definition.url
            .replace('{legacyImport}', parsedArgs.legacyImport.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\LegacyImportController::verify
 * @see app/Http/Controllers/LegacyImportController.php:213
 * @route '/legacy-imports/{legacyImport}/verify'
 */
verify.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: verify.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\LegacyImportController::verify
 * @see app/Http/Controllers/LegacyImportController.php:213
 * @route '/legacy-imports/{legacyImport}/verify'
 */
    const verifyForm = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: verify.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\LegacyImportController::verify
 * @see app/Http/Controllers/LegacyImportController.php:213
 * @route '/legacy-imports/{legacyImport}/verify'
 */
        verifyForm.post = (args: { legacyImport: string | { id: string } } | [legacyImport: string | { id: string } ] | string | { id: string }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: verify.url(args, options),
            method: 'post',
        })
    
    verify.form = verifyForm
const LegacyImportController = { index, store, show, preview, validateBatch, mapBranch, execute, verify }

export default LegacyImportController