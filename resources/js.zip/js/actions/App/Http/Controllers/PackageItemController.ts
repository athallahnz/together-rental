import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PackageItemController::store
 * @see app/Http/Controllers/PackageItemController.php:16
 * @route '/catalog/packages/{rentalPackage}/items'
 */
export const store = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/catalog/packages/{rentalPackage}/items',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PackageItemController::store
 * @see app/Http/Controllers/PackageItemController.php:16
 * @route '/catalog/packages/{rentalPackage}/items'
 */
store.url = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { rentalPackage: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { rentalPackage: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    rentalPackage: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        rentalPackage: typeof args.rentalPackage === 'object'
                ? args.rentalPackage.id
                : args.rentalPackage,
                }

    return store.definition.url
            .replace('{rentalPackage}', parsedArgs.rentalPackage.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackageItemController::store
 * @see app/Http/Controllers/PackageItemController.php:16
 * @route '/catalog/packages/{rentalPackage}/items'
 */
store.post = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PackageItemController::store
 * @see app/Http/Controllers/PackageItemController.php:16
 * @route '/catalog/packages/{rentalPackage}/items'
 */
    const storeForm = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PackageItemController::store
 * @see app/Http/Controllers/PackageItemController.php:16
 * @route '/catalog/packages/{rentalPackage}/items'
 */
        storeForm.post = (args: { rentalPackage: number | { id: number } } | [rentalPackage: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\PackageItemController::destroy
 * @see app/Http/Controllers/PackageItemController.php:39
 * @route '/catalog/package-items/{packageItem}'
 */
export const destroy = (args: { packageItem: number | { id: number } } | [packageItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/catalog/package-items/{packageItem}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\PackageItemController::destroy
 * @see app/Http/Controllers/PackageItemController.php:39
 * @route '/catalog/package-items/{packageItem}'
 */
destroy.url = (args: { packageItem: number | { id: number } } | [packageItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { packageItem: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { packageItem: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    packageItem: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        packageItem: typeof args.packageItem === 'object'
                ? args.packageItem.id
                : args.packageItem,
                }

    return destroy.definition.url
            .replace('{packageItem}', parsedArgs.packageItem.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PackageItemController::destroy
 * @see app/Http/Controllers/PackageItemController.php:39
 * @route '/catalog/package-items/{packageItem}'
 */
destroy.delete = (args: { packageItem: number | { id: number } } | [packageItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\PackageItemController::destroy
 * @see app/Http/Controllers/PackageItemController.php:39
 * @route '/catalog/package-items/{packageItem}'
 */
    const destroyForm = (args: { packageItem: number | { id: number } } | [packageItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PackageItemController::destroy
 * @see app/Http/Controllers/PackageItemController.php:39
 * @route '/catalog/package-items/{packageItem}'
 */
        destroyForm.delete = (args: { packageItem: number | { id: number } } | [packageItem: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const PackageItemController = { store, destroy }

export default PackageItemController