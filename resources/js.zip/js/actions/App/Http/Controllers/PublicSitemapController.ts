import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicSitemapController::__invoke
 * @see app/Http/Controllers/PublicSitemapController.php:13
 * @route '/sitemap.xml'
 */
const PublicSitemapController = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PublicSitemapController.url(options),
    method: 'get',
})

PublicSitemapController.definition = {
    methods: ["get","head"],
    url: '/sitemap.xml',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicSitemapController::__invoke
 * @see app/Http/Controllers/PublicSitemapController.php:13
 * @route '/sitemap.xml'
 */
PublicSitemapController.url = (options?: RouteQueryOptions) => {
    return PublicSitemapController.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicSitemapController::__invoke
 * @see app/Http/Controllers/PublicSitemapController.php:13
 * @route '/sitemap.xml'
 */
PublicSitemapController.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: PublicSitemapController.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicSitemapController::__invoke
 * @see app/Http/Controllers/PublicSitemapController.php:13
 * @route '/sitemap.xml'
 */
PublicSitemapController.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: PublicSitemapController.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicSitemapController::__invoke
 * @see app/Http/Controllers/PublicSitemapController.php:13
 * @route '/sitemap.xml'
 */
    const PublicSitemapControllerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: PublicSitemapController.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicSitemapController::__invoke
 * @see app/Http/Controllers/PublicSitemapController.php:13
 * @route '/sitemap.xml'
 */
        PublicSitemapControllerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PublicSitemapController.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicSitemapController::__invoke
 * @see app/Http/Controllers/PublicSitemapController.php:13
 * @route '/sitemap.xml'
 */
        PublicSitemapControllerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: PublicSitemapController.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    PublicSitemapController.form = PublicSitemapControllerForm
export default PublicSitemapController